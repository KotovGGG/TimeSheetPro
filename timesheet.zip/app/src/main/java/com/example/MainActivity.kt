package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import com.example.data.local.entity.ThemeMode
import com.example.ui.navigation.MainAppNavigation
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.screens.timer.TimerStateManager
import com.example.ui.screens.timer.TimerService
import com.example.ui.screens.timer.TimerStatus

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    if (savedInstanceState == null) {
      handleWidgetAction(intent)
    } else {
      intent?.action = null
    }
    
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
      }
    }
    
    val settingsRepository = (application as TimeSheetApp).container.settingsRepository
    
    setContent {
      val settings = settingsRepository.getSettingsFlow().collectAsState(initial = null).value
      val currentTheme = settings?.themeMode ?: ThemeMode.SYSTEM
      val darkTheme = when (currentTheme) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
      }
      MyApplicationTheme(darkTheme = darkTheme) {
        MainAppNavigation(modifier = Modifier.fillMaxSize())
      }
    }
  }

  override fun onStop() {
    super.onStop()
    com.example.utils.AutoBackupManager.triggerBackup(this)
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    handleWidgetAction(intent)
  }

  private fun handleWidgetAction(intent: Intent?) {
    if (intent?.action == "ACTION_WIDGET_FINISH") {
      TimerStateManager.initialize(applicationContext)
      val status = TimerStateManager.timerState.value.status
      if (status == TimerStatus.RUNNING || status == TimerStatus.PAUSED) {
        TimerStateManager.setShowConfirmDialog(true)
      } else {
        TimerStateManager.setShowConfirmDialog(false)
      }
      intent.action = null
      setIntent(intent)
    }
  }
}


