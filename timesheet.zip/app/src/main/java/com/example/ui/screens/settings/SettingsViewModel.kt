package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AmountRoundingMode
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.FirstDayOfWeek
import com.example.data.local.entity.ThemeMode
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

import com.example.data.local.entity.Client
import com.example.data.local.entity.TimeEntry
import com.example.data.local.entity.RateHistoryEntry
import com.example.data.repository.ClientRepository
import com.example.data.repository.TimeEntryRepository
import com.example.data.repository.RateHistoryRepository
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class BackupPayload(
    val schemaVersion: Int,
    val clients: List<Client>,
    val rateHistory: List<RateHistoryEntry>,
    val timeEntries: List<TimeEntry>,
    val appSettings: AppSettings?
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val clientRepository: ClientRepository,
    private val timeEntryRepository: TimeEntryRepository,
    private val rateHistoryRepository: RateHistoryRepository,
    private val database: AppDatabase
) : ViewModel() {

    // Expose Settings UI State, initialize with default if null in db
    val settingsState: StateFlow<AppSettings> = settingsRepository.getSettingsFlow()
        .map { settings ->
            if (settings == null) {
                val defaultSettings = AppSettings()
                viewModelScope.launch {
                    settingsRepository.saveSettings(defaultSettings)
                }
                defaultSettings
            } else {
                settings
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    val clientsState: StateFlow<List<Client>> = clientRepository.getAllClients()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val timeEntriesState: StateFlow<List<TimeEntry>> = timeEntryRepository.getAllTimeEntries()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateGlobalRate(rate: Double) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(globalHourlyRate = rate))
        }
    }

    fun updateCurrency(currency: String) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(currency = currency))
        }
    }

    fun updateTimeRounding(minutes: Int) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(timeRoundingMinutes = minutes))
        }
    }

    fun updateFirstDayOfWeek(day: FirstDayOfWeek) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(firstDayOfWeek = day))
        }
    }

    fun updateAmountRoundingMode(mode: AmountRoundingMode) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(amountRoundingMode = mode))
        }
    }

    fun updateAmountRoundingStep(step: Double) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(amountRoundingStep = step))
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            val current = settingsState.value
            settingsRepository.saveSettings(current.copy(themeMode = mode))
        }
    }

    suspend fun createBackupJson(): String {
        val settings = settingsState.value
        val clients = clientsState.value
        val timeEntries = timeEntriesState.value
        val rateHistory = rateHistoryRepository.getAllHistory().first()

        val payload = BackupPayload(
            schemaVersion = 1,
            clients = clients,
            rateHistory = rateHistory,
            timeEntries = timeEntries,
            appSettings = settings
        )
        return Json.encodeToString(BackupPayload.serializer(), payload)
    }

    suspend fun restoreBackupJson(jsonString: String): Result<Unit> {
        return try {
            val payload = Json.decodeFromString(BackupPayload.serializer(), jsonString)
            if (payload.schemaVersion < 1) {
                return Result.failure(Exception("Некорректная версия схемы бэкапа"))
            }
            database.restoreBackup(
                clientsList = payload.clients,
                rateHistoryList = payload.rateHistory,
                timeEntriesList = payload.timeEntries,
                settings = payload.appSettings
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
