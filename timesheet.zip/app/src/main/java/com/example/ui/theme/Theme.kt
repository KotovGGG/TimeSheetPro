package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = BrassAccent,
    onPrimary = Color.White,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = InkGreenAccent,
    onSecondary = Color.White,
    tertiary = InkGreenAccent,
    onTertiary = Color.White,
    background = PaperBackground,
    onBackground = InkText,
    surface = LightSurface,
    onSurface = InkText,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = Color(0xFF525065),
    outline = LightOutline,
    error = WarningRedAccent,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = CustomAccentLavender,
    onPrimary = CustomBackground,
    secondary = CustomAccentPink,
    onSecondary = CustomBackground,
    tertiary = CustomAccentPink,
    onTertiary = CustomBackground,
    background = CustomBackground,
    onBackground = Color.White,
    surface = CustomSurface,
    onSurface = Color.White,
    surfaceVariant = CustomSurface,
    onSurfaceVariant = Color.White,
    outline = CustomOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    // We explicitly disable dynamic color to strictly adhere to the requested "ledger-chronometer" design
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
