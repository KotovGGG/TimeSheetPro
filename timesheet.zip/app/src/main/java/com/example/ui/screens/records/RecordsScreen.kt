package com.example.ui.screens.records

import android.app.DatePickerDialog
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.SizeTransform
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.local.entity.Client
import com.example.data.local.entity.Report
import com.example.data.local.entity.ReportStatus
import com.example.data.local.entity.TimeEntry
import com.example.data.local.entity.TimeEntryStatus
import androidx.compose.ui.window.Dialog
import com.example.data.repository.SortOrder
import com.example.ui.AppViewModelProvider
import com.example.ui.screens.timer.TimePickerDialog
import com.example.ui.screens.timer.ComposeDatePickerDialog
import com.example.ui.screens.timer.customTimePickerColors
import com.example.ui.screens.timer.formatCurrency
import com.example.ui.screens.timer.formatHours
import com.example.ui.screens.timer.safeParseColor
import com.example.ui.theme.LedgerStyles
import com.example.utils.export.PdfGenerator
import com.example.utils.export.XlsxColumn
import com.example.utils.export.XlsxGenerator
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay

private fun getStatusColors(status: TimeEntryStatus): Triple<Color, Color, Color> {
    return when (status) {
        TimeEntryStatus.PAID -> Triple(
            Color(0xFF1B5E20).copy(alpha = 0.15f),
            Color(0xFF4CAF50),
            Color(0xFF81C784)
        )
        TimeEntryStatus.INVOICED -> Triple(
            Color(0xFFE65100).copy(alpha = 0.15f),
            Color(0xFFFF9800),
            Color(0xFFFFB74D)
        )
        TimeEntryStatus.NOT_PAID -> Triple(
            Color(0xFFB71C1C).copy(alpha = 0.15f),
            Color(0xFFF44336),
            Color(0xFFE57373)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun RecordsScreen(
    modifier: Modifier = Modifier,
    viewModel: RecordsViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val entries by viewModel.timeEntriesState.collectAsState()
    val clients by viewModel.clientsState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val unpaidBalances by viewModel.unpaidBalancesState.collectAsState()

    // Search and filter state from ViewModel
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedClients by viewModel.selectedClients.collectAsState()
    val selectedStatuses by viewModel.selectedStatuses.collectAsState()
    val currentSortOrder by viewModel.sortOrder.collectAsState()
    val selectedPeriod by viewModel.selectedPeriod.collectAsState()
    val customStartDate by viewModel.customStartDate.collectAsState()
    val customEndDate by viewModel.customEndDate.collectAsState()

    // Bulk export state
    var showBulkExportBottomSheet by remember { mutableStateOf(false) }
    var bulkExportFormat by remember { mutableStateOf("XLSX") }
    val bulkExportSelectedXlsxColumns = remember { mutableStateListOf<XlsxColumn>(*XlsxColumn.values()) }
    var bulkExportSuccessCard by remember { mutableStateOf(false) }

    // Selection mode state
    var selectedEntryIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val isSelectionMode = selectedEntryIds.isNotEmpty()

    // Back Handler for selection mode
    if (isSelectionMode) {
        BackHandler {
            selectedEntryIds = emptySet()
        }
    }

    // Dialog form states
    var showManualAddDialog by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<TimeEntry?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<TimeEntry?>(null) }

    // Manual add form state
    var selectedClientId by remember { mutableStateOf<Long?>(null) }
    var manualComment by remember { mutableStateOf("") }
    var manualHours by remember { mutableStateOf(1) }
    var manualMinutes by remember { mutableStateOf(0) }
    var manualDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
    var manualShowTimePicker by remember { mutableStateOf(false) }

    // Auto-select first or last selected client
    LaunchedEffect(clients) {
        if (selectedClientId == null && clients.isNotEmpty()) {
            val lastId = com.example.ui.screens.timer.TimerStateManager.getLastSelectedClientId()
            val hasLastActive = lastId != null && clients.any { it.id == lastId }
            selectedClientId = if (hasLastActive) lastId else clients.first().id
        }
    }

    val totalHoursSeconds = entries.sumOf { it.durationSeconds }
    val totalEarnings = entries.sumOf { it.amount }

    // Date formatting helpers
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val displayDateFormatter = remember { SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ru")) }
    val timeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    // Grouping only applies visually on screen. Under GROUP BY client we can still display date headers 
    // or group them as a single list depending on sort mode.
    val groupedEntries = remember(entries, currentSortOrder) {
        if (currentSortOrder == SortOrder.CLIENT) {
            // Group by Client instead of Date
            entries.groupBy { "client_${it.clientId}" }
        } else {
            entries.groupBy { entry -> dateFormatter.format(Date(entry.startTime)) }
        }
    }

    // Bottom sheets toggle
    var showFilterBottomSheet by remember { mutableStateOf(false) }
    var showExportBottomSheet by remember { mutableStateOf(false) }
    var showReportsHistoryBottomSheet by remember { mutableStateOf(false) }
    var statusDropdownEntry by remember { mutableStateOf<TimeEntry?>(null) }
    val reportsHistory by viewModel.reportsState.collectAsState()
    var selectedReportForDetails by remember { mutableStateOf<Report?>(null) }
    var selectedReportForPayment by remember { mutableStateOf<Report?>(null) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showDatePickerState by remember { mutableStateOf(false) }
    var datePickerInitialTime by remember { mutableStateOf(0L) }
    var onDateSelectedCallback by remember { mutableStateOf<((Long) -> Unit)?>(null) }

    // Date Picker helper
    fun showDatePicker(initialTime: Long, onDateSelected: (Long) -> Unit) {
        datePickerInitialTime = initialTime
        onDateSelectedCallback = onDateSelected
        showDatePickerState = true
    }

    if (showDatePickerState && onDateSelectedCallback != null) {
        ComposeDatePickerDialog(
            initialTimeMs = datePickerInitialTime,
            onDismissRequest = { showDatePickerState = false },
            onDateSelected = { selectedDate ->
                onDateSelectedCallback?.invoke(selectedDate)
            }
        )
    }

    // --- Export States ---
    var exportFormat by remember { mutableStateOf("XLSX") } // "XLSX" or "PDF"
    val exportSelectedClients = remember { mutableStateListOf<Long>() }
    val exportSelectedStatuses = remember { mutableStateListOf<TimeEntryStatus>(TimeEntryStatus.NOT_PAID) }
    var exportPeriodPreset by remember { mutableStateOf("ALL") } // "ALL", "WEEK", "MONTH", "CUSTOM"
    var exportCustomStartDate by remember { mutableStateOf(System.currentTimeMillis() - 7 * 24 * 3600 * 1000) }
    var exportCustomEndDate by remember { mutableStateOf(System.currentTimeMillis()) }
    val exportSelectedXlsxColumns = remember { mutableStateListOf<XlsxColumn>(*XlsxColumn.values()) }

    var generatedFileBytes by remember { mutableStateOf<ByteArray?>(null) }
    var generatedFileName by remember { mutableStateOf("") }
    var generatedMimeType by remember { mutableStateOf("") }
    var showExportSuccessCard by remember { mutableStateOf(false) }

    // SAF File Creator Launcher
    val createDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(generatedMimeType),
        onResult = { uri ->
            if (uri != null && generatedFileBytes != null) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(generatedFileBytes)
                    }
                    android.widget.Toast.makeText(context, "Файл успешно сохранен!", android.widget.Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "Ошибка сохранения: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (isSelectionMode) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF17171F))
                ) {
                    Surface(
                        tonalElevation = 6.dp,
                        shadowElevation = 8.dp,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 12.dp, bottom = 12.dp, top = 4.dp)
                    ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            IconButton(onClick = { selectedEntryIds = emptySet() }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Отмена",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Text(
                                text = "Выбрано: ${selectedEntryIds.size}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Bulk export report for selected entries
                            IconButton(onClick = {
                                bulkExportSuccessCard = false
                                showBulkExportBottomSheet = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.FileUpload,
                                    contentDescription = "Экспортировать отчёт",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }

                            // Status bulk update
                            var showBulkStatusMenu by remember { mutableStateOf(false) }
                            Box {
                                IconButton(onClick = { showBulkStatusMenu = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Label,
                                        contentDescription = "Изменить статус",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            if (showBulkStatusMenu) {
                                ModalBottomSheet(
                                    onDismissRequest = { showBulkStatusMenu = false },
                                    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                    dragHandle = { BottomSheetDefaults.DragHandle() }
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 24.dp)
                                            .padding(bottom = 32.dp),
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        Text(
                                            text = "Изменить статус",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .verticalScroll(rememberScrollState()),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            TimeEntryStatus.values().forEach { status ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .clickable {
                                                            viewModel.updateBulkStatuses(selectedEntryIds.toList(), status)
                                                            showBulkStatusMenu = false
                                                            selectedEntryIds = emptySet()
                                                        }
                                                        .padding(16.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = when (status) {
                                                            TimeEntryStatus.PAID -> "Оплачено"
                                                            TimeEntryStatus.INVOICED -> "Счёт выставлен"
                                                            TimeEntryStatus.NOT_PAID -> "Не оплачен"
                                                        },
                                                        style = MaterialTheme.typography.bodyLarge,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                                                                   // Bulk delete action
                            var showBulkDeleteConfirm by remember { mutableStateOf(false) }
                            IconButton(onClick = { showBulkDeleteConfirm = true }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Удалить",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }

                            if (showBulkDeleteConfirm) {
                                AlertDialog(
                                    onDismissRequest = { showBulkDeleteConfirm = false },
                                    title = { Text("Удалить выбранные записи?") },
                                    text = {
                                        Text("Вы действительно хотите удалить ${getRecordsPluralString(selectedEntryIds.size)}? Это действие нельзя отменить.")
                                    },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.deleteBulkEntries(selectedEntryIds.toList())
                                                showBulkDeleteConfirm = false
                                                selectedEntryIds = emptySet()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("Удалить")
                                        }
                                    },
                                    dismissButton = {
                                        OutlinedButton(
                                            onClick = { showBulkDeleteConfirm = false },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        ) {
                                            Text("Отмена")
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    },
        floatingActionButton = {
            if (!isSelectionMode) {
                FloatingActionButton(
                    onClick = { showManualAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .padding(bottom = 4.dp)
                        .size(64.dp)
                        .testTag("add_manual_record_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Вручную добавить запись",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        },
        containerColor = Color(0xFF17171F),
        modifier = modifier
    ) { innerPadding ->
        val activeMonthVal by viewModel.activeMonth.collectAsState()
        val monthFormat = remember { SimpleDateFormat("LLLL yyyy", Locale("ru")) }

        var monthSwipeDirection by remember { mutableIntStateOf(1) }
        var dragOffsetX by remember { mutableFloatStateOf(0f) }
        val animatedDragOffset by animateFloatAsState(
            targetValue = dragOffsetX,
            animationSpec = spring(
                stiffness = Spring.StiffnessMedium,
                dampingRatio = Spring.DampingRatioNoBouncy
            ),
            label = "animatedDragOffset"
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .then(
                    if (selectedPeriod == "MONTH" && !isSelectionMode) {
                        Modifier.pointerInput(selectedPeriod, isSelectionMode) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragOffsetX = 0f },
                                onDragEnd = {
                                    if (dragOffsetX < -80f) {
                                        monthSwipeDirection = 1
                                        viewModel.navigateMonth(1)
                                    } else if (dragOffsetX > 80f) {
                                        monthSwipeDirection = -1
                                        viewModel.navigateMonth(-1)
                                    }
                                    dragOffsetX = 0f
                                },
                                onDragCancel = { dragOffsetX = 0f },
                                onHorizontalDrag = { change, dragAmount ->
                                    change.consume()
                                    dragOffsetX += dragAmount
                                }
                            )
                        }
                    } else {
                        Modifier
                    }
                ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Header & Search Bar Grouped to prevent spacedBy jump ---
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Записи",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { showExportBottomSheet = true }) {
                            Icon(
                                imageVector = Icons.Default.FileUpload,
                                contentDescription = "Экспорт отчётов",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { showReportsHistoryBottomSheet = true }) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "История отчётов",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { showFilterBottomSheet = true }) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Фильтры",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // --- Dynamic wrapping FlowRow for active filter chips ---
            val hasActiveFilters = selectedClients.isNotEmpty() || selectedStatuses.isNotEmpty() || selectedPeriod != "MONTH"
            if (hasActiveFilters && !isSelectionMode) {
                @OptIn(ExperimentalLayoutApi::class)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Reset all filters chip
                    InputChip(
                        selected = true,
                        onClick = { viewModel.clearAllFilters() },
                        label = { Text("Сбросить всё", fontWeight = FontWeight.Bold) },
                        trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        colors = InputChipDefaults.inputChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.errorContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onErrorContainer
                        )
                    )

                    // Period active chip
                    if (selectedPeriod != "MONTH") {
                        val periodLabel = when (selectedPeriod) {
                            "WEEK" -> "Эта неделя"
                            "ALL" -> "За весь период"
                            "CUSTOM" -> {
                                val fmt = SimpleDateFormat("dd.MM.yy", Locale.getDefault())
                                "${fmt.format(Date(customStartDate ?: 0))}—${fmt.format(Date(customEndDate ?: 0))}"
                            }
                            else -> "Этот месяц"
                        }
                        InputChip(
                            selected = true,
                            onClick = { viewModel.applyFilters(selectedClients, selectedStatuses, currentSortOrder, "MONTH", null, null) },
                            label = { Text(periodLabel) },
                            trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                    }

                    // Selected Client chips
                    selectedClients.forEach { clientId ->
                        val client = clients.find { it.id == clientId }
                        if (client != null) {
                            InputChip(
                                selected = true,
                                onClick = {
                                    val updated = selectedClients.toMutableSet().apply { remove(clientId) }
                                    viewModel.applyFilters(updated, selectedStatuses, currentSortOrder, selectedPeriod, customStartDate, customEndDate)
                                },
                                label = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(safeParseColor(client.colorHex))
                                        )
                                        Text(client.name)
                                    }
                                },
                                trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            )
                        }
                    }

                    // Selected Status chips
                    selectedStatuses.forEach { status ->
                        InputChip(
                            selected = true,
                            onClick = {
                                val updated = selectedStatuses.toMutableSet().apply { remove(status) }
                                viewModel.applyFilters(selectedClients, updated, currentSortOrder, selectedPeriod, customStartDate, customEndDate)
                            },
                            label = {
                                Text(
                                    when (status) {
                                        TimeEntryStatus.PAID -> "Оплачено"
                                        TimeEntryStatus.INVOICED -> "Счёт выставлен"
                                        TimeEntryStatus.NOT_PAID -> "Не оплачен"
                                    }
                                )
                            },
                            trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }
            }

            // --- Month Navigation Card ---
            if (selectedPeriod == "MONTH" && !isSelectionMode) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.25f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                monthSwipeDirection = -1
                                viewModel.navigateMonth(-1)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowLeft,
                                contentDescription = "Предыдущий месяц",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        AnimatedContent(
                            targetState = activeMonthVal.timeInMillis,
                            transitionSpec = {
                                val duration = 280
                                val easing = FastOutSlowInEasing
                                if (monthSwipeDirection > 0) {
                                    (slideInHorizontally(animationSpec = tween(duration, easing = easing)) { width -> width / 2 } + fadeIn(animationSpec = tween(duration)))
                                        .togetherWith(slideOutHorizontally(animationSpec = tween(duration, easing = easing)) { width -> -width / 2 } + fadeOut(animationSpec = tween(duration)))
                                } else {
                                    (slideInHorizontally(animationSpec = tween(duration, easing = easing)) { width -> -width / 2 } + fadeIn(animationSpec = tween(duration)))
                                        .togetherWith(slideOutHorizontally(animationSpec = tween(duration, easing = easing)) { width -> width / 2 } + fadeOut(animationSpec = tween(duration)))
                                }
                            },
                            label = "MonthLabelAnimation",
                            modifier = Modifier.weight(1f)
                        ) { _ ->
                            val currentLabel = monthFormat.format(activeMonthVal.time).replaceFirstChar { it.uppercase() }
                            Text(
                                text = currentLabel,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        
                        IconButton(
                            onClick = {
                                monthSwipeDirection = 1
                                viewModel.navigateMonth(1)
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowRight,
                                contentDescription = "Следующий месяц",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // --- Historical Accumulations & Records Container with Month Swipe Animation & Touch Drag ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .graphicsLayer { translationX = animatedDragOffset }
            ) {
                AnimatedContent(
                    targetState = if (selectedPeriod == "MONTH") activeMonthVal.timeInMillis else 0L,
                    transitionSpec = {
                        val duration = 280
                        val easing = FastOutSlowInEasing
                        if (monthSwipeDirection > 0) {
                            (slideInHorizontally(animationSpec = tween(duration, easing = easing)) { width -> width } + fadeIn(animationSpec = tween(200)))
                                .togetherWith(slideOutHorizontally(animationSpec = tween(duration, easing = easing)) { width -> -width } + fadeOut(animationSpec = tween(200)))
                        } else {
                            (slideInHorizontally(animationSpec = tween(duration, easing = easing)) { width -> -width } + fadeIn(animationSpec = tween(200)))
                                .togetherWith(slideOutHorizontally(animationSpec = tween(duration, easing = easing)) { width -> width } + fadeOut(animationSpec = tween(200)))
                        }
                    },
                    label = "MonthContentAnimation",
                    modifier = Modifier.fillMaxSize()
                ) { _ ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Historical Accumulations Card (Animate smoothly in and out during selection mode)
                        AnimatedVisibility(
                            visible = !isSelectionMode,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = "ОБЩАЯ СТАТИСТИКА",
                                style = LedgerStyles.UppercaseSectionHeader,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Start,
                                modifier = Modifier.align(Alignment.CenterStart)
                            )
                            if (currentSortOrder != SortOrder.TIME_DESC) {
                                val sortingLabel = when (currentSortOrder) {
                                    SortOrder.TIME_ASC -> "Старые сначала"
                                    SortOrder.CLIENT -> "По заказчику"
                                    else -> "Новые сначала"
                                }
                                Text(
                                    text = sortingLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                    modifier = Modifier.align(Alignment.CenterEnd)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = "ОТРАБОТАНО",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = formatHours(totalHoursSeconds),
                                    style = LedgerStyles.MonospaceNumberMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 16.dp)
                                    .width(1.dp)
                                    .height(36.dp)
                                    .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = "ОБЩАЯ СУММА",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Start
                                )
                                Text(
                                    text = formatCurrency(totalEarnings, settings.currency),
                                    style = LedgerStyles.MonospaceNumberMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(top = 2.dp),
                                    textAlign = TextAlign.Start
                                )
                            }
                        }
                    }
                }
            }

            // --- List of records ---
            if (entries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HistoryToggleOff,
                            contentDescription = "Empty Records",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "Записи не найдены",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Попробуйте изменить параметры поиска или фильтров.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .testTag("records_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    groupedEntries.forEach { (groupKey, groupEntries) ->
                        // Show header for group
                        item(key = "hdr_$groupKey") {
                            val headerText = if (currentSortOrder == SortOrder.CLIENT) {
                                val clientId = groupKey.substringAfter("client_").toLongOrNull() ?: 0L
                                val client = clients.find { it.id == clientId }
                                (client?.name ?: "Unknown Client").uppercase()
                            } else {
                                val parsedDate = dateFormatter.parse(groupKey) ?: Date()
                                displayDateFormatter.format(parsedDate).uppercase()
                            }

                            val groupDuration = groupEntries.sumOf { it.durationSeconds }
                            val groupEarnings = groupEntries.sumOf { it.amount }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = headerText,
                                        style = LedgerStyles.UppercaseSectionHeader,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = formatHours(groupDuration),
                                            style = LedgerStyles.MonospaceNumberSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = formatCurrency(groupEarnings, settings.currency),
                                            style = LedgerStyles.MonospaceNumberSmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp)
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                )
                            }
                        }

                        items(groupEntries, key = { it.id }) { entry ->
                            val client = remember(entry.clientId, clients) { clients.find { it.id == entry.clientId } }
                            val defaultColor = MaterialTheme.colorScheme.primary
                            val clientColor = remember(client, defaultColor) { client?.colorHex?.let { safeParseColor(it) } ?: defaultColor }
                            val isSelected = selectedEntryIds.contains(entry.id)
                            val statusColors = remember(entry.status) { getStatusColors(entry.status) }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        if (isSelected) {
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    )
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                                        },
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .combinedClickable(
                                        onClick = {
                                            if (isSelectionMode) {
                                                selectedEntryIds = if (isSelected) {
                                                    selectedEntryIds - entry.id
                                                } else {
                                                    selectedEntryIds + entry.id
                                                }
                                            } else {
                                                editingEntry = entry
                                            }
                                        },
                                        onLongClick = {
                                            if (!isSelectionMode) {
                                                selectedEntryIds = setOf(entry.id)
                                            }
                                        }
                                    )
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Client Indicator Pill on the side (using status colors)
                                Box(
                                    modifier = Modifier
                                        .width(5.dp)
                                        .fillMaxHeight()
                                        .clip(CircleShape)
                                        .background(statusColors.second)
                                )

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${timeFormatter.format(Date(entry.startTime))} - ${timeFormatter.format(Date(entry.endTime!!))}",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (!entry.comment.isNullOrBlank()) {
                                        Text(
                                            text = entry.comment,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .padding(top = 4.dp)
                                            .background(
                                                color = clientColor.copy(alpha = 0.12f),
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = clientColor.copy(alpha = 0.4f),
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = client?.name ?: "Unknown Client",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Column(
                                    horizontalAlignment = Alignment.End,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // Duration hours
                                    Text(
                                        text = formatHours(entry.durationSeconds),
                                        style = LedgerStyles.MonospaceNumberSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    // Earnings
                                    Text(
                                        text = formatCurrency(entry.amount, settings.currency),
                                        style = LedgerStyles.MonospaceNumberMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )

                                    // Payment Status Quick Toggle
                                    Box(
                                        modifier = Modifier
                                            .clickable {
                                                if (!isSelectionMode) {
                                                    statusDropdownEntry = entry
                                                }
                                            }
                                            .padding(vertical = 4.dp)
                                            .testTag("status_badge_${entry.id}")
                                    ) {
                                        Text(
                                            text = when (entry.status) {
                                                TimeEntryStatus.PAID -> "ОПЛАЧЕНО"
                                                TimeEntryStatus.INVOICED -> "СЧЁТ ВЫСТАВЛЕН"
                                                TimeEntryStatus.NOT_PAID -> "НЕ ОПЛАЧЕН"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = statusColors.second,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
}

    // --- Edit Record Dialog ---
    editingEntry?.let { entry ->
        val editDateFormatter = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()) }
        val editTimeFormatter = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

        val calendar = Calendar.getInstance().apply { timeInMillis = entry.startTime }
        var editDateMs by remember { mutableStateOf(entry.startTime) }
        var editHours by remember { mutableStateOf(calendar.get(Calendar.HOUR_OF_DAY)) }
        var editMinutes by remember { mutableStateOf(calendar.get(Calendar.MINUTE)) }
        var showEditTimePicker by remember { mutableStateOf(false) }

        val initialDurationMinutes = entry.durationSeconds / 60
        var editDurationHours by remember { mutableStateOf((initialDurationMinutes / 60).toInt()) }
        var editDurationMinutes by remember { mutableStateOf((initialDurationMinutes % 60).toInt()) }
        var showEditDurationPicker by remember { mutableStateOf(false) }

        var commentInput by remember { mutableStateOf(entry.comment ?: "") }
        var selectedClientEditId by remember { mutableStateOf(entry.clientId) }
        var selectedStatus by remember { mutableStateOf(entry.status) }

        var durationError by remember { mutableStateOf(false) }
        var clientDropdownExpanded by remember { mutableStateOf(false) }

        val displayDateFormatter = remember { SimpleDateFormat("d MMMM, yyyy", Locale("ru")) }
        val formattedTime = String.format(Locale.US, "%02d:%02d", editHours, editMinutes)

        if (showEditTimePicker) {
            val timePickerState = rememberTimePickerState(
                initialHour = editHours,
                initialMinute = editMinutes,
                is24Hour = true
            )
            
            TimePickerDialog(
                onDismissRequest = { showEditTimePicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            editHours = timePickerState.hour
                            editMinutes = timePickerState.minute
                            showEditTimePicker = false
                        }
                    ) {
                        Text("OK", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditTimePicker = false }) {
                        Text("Отмена")
                    }
                }
            ) {
                MaterialTheme(
                    typography = MaterialTheme.typography.copy(
                        bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        ),
                        labelMedium = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp
                        )
                    )
                ) {
                    TimePicker(
                        state = timePickerState,
                        colors = customTimePickerColors()
                    )
                }
            }
        }

        if (showEditDurationPicker) {
            val durationPickerState = rememberTimePickerState(
                initialHour = editDurationHours,
                initialMinute = editDurationMinutes,
                is24Hour = true
            )
            
            TimePickerDialog(
                onDismissRequest = { showEditDurationPicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            editDurationHours = durationPickerState.hour
                            editDurationMinutes = durationPickerState.minute
                            showEditDurationPicker = false
                        }
                    ) {
                        Text("OK", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDurationPicker = false }) {
                        Text("Отмена")
                    }
                }
            ) {
                MaterialTheme(
                    typography = MaterialTheme.typography.copy(
                        bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        ),
                        labelMedium = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp
                        )
                    )
                ) {
                    TimePicker(
                        state = durationPickerState,
                        colors = customTimePickerColors()
                    )
                }
            }
        }

        ModalBottomSheet(
            onDismissRequest = { editingEntry = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header with Title
                    Text(
                        text = "Редактировать запись",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )

                        // Date and Start Time Button Combined
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Дата и время начала работы",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = {
                                    showDatePicker(editDateMs) { dateMs ->
                                        editDateMs = dateMs
                                        showEditTimePicker = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "Select date and start time",
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "${displayDateFormatter.format(Date(editDateMs))} в $formattedTime",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Duration Picker Button (looks like work time in save session)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Длительность работы",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val formattedDuration = String.format(Locale.US, "%02d:%02d", editDurationHours, editDurationMinutes)
                            OutlinedButton(
                                onClick = { showEditDurationPicker = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = "Select work duration",
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Время работы: $formattedDuration",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Comment Input
                        OutlinedTextField(
                            value = commentInput,
                            onValueChange = { commentInput = it },
                            label = { Text("Описание работ") },
                            modifier = Modifier.fillMaxWidth().testTag("edit_comment_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            singleLine = true
                        )

                        // Client Selector dropdown (moved after comment)
                        val client = clients.find { it.id == selectedClientEditId }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Заказчик",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = client?.name ?: "Выберите заказчика",
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = false,
                                    leadingIcon = {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(client?.colorHex?.let { safeParseColor(it) } ?: MaterialTheme.colorScheme.primary)
                                        )
                                    },
                                    trailingIcon = {
                                        val arrowRotation by animateFloatAsState(
                                            targetValue = if (clientDropdownExpanded) 180f else 0f,
                                            label = "ArrowRotation"
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = "Dropdown Arrow",
                                            modifier = Modifier.rotate(arrowRotation),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                        disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledContainerColor = Color.Transparent
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { clientDropdownExpanded = true },
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }

                        // Status Selection with chips
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "Статус оплаты",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TimeEntryStatus.values().forEach { status ->
                                    val isSelected = selectedStatus == status
                                    val label = when (status) {
                                        TimeEntryStatus.PAID -> "Оплачено"
                                        TimeEntryStatus.INVOICED -> "Счёт выставлен"
                                        TimeEntryStatus.NOT_PAID -> "Не оплачен"
                                    }
                                    
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedStatus = status },
                                        label = {
                                            Text(
                                                text = label,
                                                fontSize = 11.sp,
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        val editTargetClient = clients.find { it.id == selectedClientEditId }
                        val editRate = editTargetClient?.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate
                        val editTotalDurationHours = (editDurationHours * 60 + editDurationMinutes) / 60.0
                        val editCalculatedAmount = settings.roundAmount(editTotalDurationHours * editRate)

                        if (editRate <= 0.0 || editCalculatedAmount <= 0.0) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Предупреждение",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Предупреждение: Расчётная сумма работы 0 (тариф 0).",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Delete button (2-го плана)
                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = entry },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Удалить запись", fontWeight = FontWeight.Bold)
                        }

                        // Row of Cancel and Save (aligned by width, equal space)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { editingEntry = null },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text("Отмена")
                            }

                            val totalDurationMinutes = editDurationHours * 60 + editDurationMinutes
                            Button(
                                onClick = {
                                    if (totalDurationMinutes > 0) {
                                        val cal = Calendar.getInstance().apply {
                                            timeInMillis = editDateMs
                                            set(Calendar.HOUR_OF_DAY, editHours)
                                            set(Calendar.MINUTE, editMinutes)
                                            set(Calendar.SECOND, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }

                                        val newStartTime = cal.timeInMillis
                                        val newDurationMs = totalDurationMinutes * 60 * 1000L
                                        val newEndTime = newStartTime + newDurationMs

                                        val targetClient = clients.find { it.id == selectedClientEditId }
                                        val currentRate = targetClient?.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate

                                        viewModel.updateTimeEntry(
                                            entry = entry,
                                            clientId = selectedClientEditId,
                                            startTime = newStartTime,
                                            endTime = newEndTime,
                                            comment = commentInput.ifBlank { null },
                                            status = selectedStatus,
                                            recalculateWithCurrentClientRate = false,
                                            currentClientRate = currentRate
                                        )

                                        editingEntry = null
                                    }
                                },
                                enabled = (editDurationHours > 0 || editDurationMinutes > 0),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text("Сохранить", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    InlineClientSelectorSheet(
                        expanded = clientDropdownExpanded,
                        onDismiss = { clientDropdownExpanded = false },
                        clients = clients,
                        selectedClientId = selectedClientEditId,
                        onClientSelected = { clientId ->
                            selectedClientEditId = clientId
                            clientDropdownExpanded = false
                        }
                    )
                }
            }
        }

    statusDropdownEntry?.let { entry ->
        ModalBottomSheet(
            onDismissRequest = { statusDropdownEntry = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Изменить статус оплаты",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TimeEntryStatus.values().forEach { status ->
                        val isSelected = entry.status == status
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    else Color.Transparent
                                )
                                .clickable {
                                    viewModel.updateEntryStatus(entry, status)
                                    statusDropdownEntry = null
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (status) {
                                    TimeEntryStatus.PAID -> "Оплачено"
                                    TimeEntryStatus.INVOICED -> "Счёт выставлен"
                                    TimeEntryStatus.NOT_PAID -> "Не оплачен"
                                },
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }

    // --- Delete Confirm Dialog ---
    showDeleteConfirmDialog?.let { entry ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Удалить запись?") },
            text = {
                Text("Вы действительно хотите удалить эту запись? Данное действие необратимо.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTimeEntry(entry)
                        showDeleteConfirmDialog = null
                        editingEntry = null // Close editor if opened
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirmDialog = null },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    Text("Отмена")
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(24.dp)
        )
    }

    // --- Manual Add Entry Dialog ---
    if (showManualAddDialog) {
        val displayFormatter = remember { SimpleDateFormat("d MMMM, yyyy", Locale("ru")) }

        var manualDropdownExpanded by remember { mutableStateOf(false) }

        val calNow = Calendar.getInstance()
        var manualStartHours by remember { mutableStateOf(calNow.get(Calendar.HOUR_OF_DAY)) }
        var manualStartMinutes by remember { mutableStateOf(calNow.get(Calendar.MINUTE)) }
        var showManualStartTimePicker by remember { mutableStateOf(false) }
        val formattedStartTime = String.format(Locale.US, "%02d:%02d", manualStartHours, manualStartMinutes)

        if (showManualStartTimePicker) {
            val startTimePickerState = rememberTimePickerState(
                initialHour = manualStartHours,
                initialMinute = manualStartMinutes,
                is24Hour = true
            )
            
            TimePickerDialog(
                onDismissRequest = { showManualStartTimePicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            manualStartHours = startTimePickerState.hour
                            manualStartMinutes = startTimePickerState.minute
                            showManualStartTimePicker = false
                        }
                    ) {
                        Text("OK", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showManualStartTimePicker = false }) {
                        Text("Отмена")
                    }
                }
            ) {
                MaterialTheme(
                    typography = MaterialTheme.typography.copy(
                        bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        ),
                        labelMedium = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp
                        )
                    )
                ) {
                    TimePicker(
                        state = startTimePickerState,
                        colors = customTimePickerColors()
                    )
                }
            }
        }

        if (manualShowTimePicker) {
            val timePickerState = rememberTimePickerState(
                initialHour = manualHours,
                initialMinute = manualMinutes,
                is24Hour = true
            )
            
            TimePickerDialog(
                onDismissRequest = { manualShowTimePicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            manualHours = timePickerState.hour
                            manualMinutes = timePickerState.minute
                            manualShowTimePicker = false
                        }
                    ) {
                        Text("OK", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { manualShowTimePicker = false }) {
                        Text("Отмена")
                    }
                }
            ) {
                MaterialTheme(
                    typography = MaterialTheme.typography.copy(
                        bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        ),
                        labelMedium = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.sp
                        )
                    )
                ) {
                    TimePicker(
                        state = timePickerState,
                        colors = customTimePickerColors()
                    )
                }
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showManualAddDialog = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header with Title
                    Text(
                        text = "Добавить запись вручную",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (clients.isEmpty()) {
                        Text(
                            text = "Пожалуйста, сначала создайте хотя бы одного заказчика на вкладке 'Заказчики'.",
                            color = MaterialTheme.colorScheme.tertiary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {

                        // Combined Date and Start Time Button
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Дата и время начала работы",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = {
                                    showDatePicker(manualDateMs) { dateMs ->
                                        manualDateMs = dateMs
                                        showManualStartTimePicker = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = "Select date and start time",
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "${displayFormatter.format(Date(manualDateMs))} в $formattedStartTime",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Duration Picker Button (looks like work time in save session)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Длительность работы",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val formattedTime = String.format(Locale.US, "%02d:%02d", manualHours, manualMinutes)
                            OutlinedButton(
                                onClick = { manualShowTimePicker = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = "Select work duration",
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Время работы: $formattedTime",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Comment/Description Input
                        OutlinedTextField(
                            value = manualComment,
                            onValueChange = { manualComment = it },
                            label = { Text("Описание выполненных работ") },
                            placeholder = { Text("Напр., Правка багов, Рефакторинг") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dialog_manual_comment_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            singleLine = true
                        )

                        // Client Selector Dropdown (moved after comment)
                        val client = clients.find { it.id == selectedClientId }
                        val manualRate = client?.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate
                        val manualDurationHours = (manualHours * 3600L + manualMinutes * 60L) / 3600.0
                        val manualCalculatedAmount = settings.roundAmount(manualDurationHours * manualRate)

                        if (manualRate <= 0.0 || manualCalculatedAmount <= 0.0) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Предупреждение",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Предупреждение: Расчётная сумма работы 0. У заказчика и в настройках не задан тариф выше 0.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Заказчик",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = client?.name ?: "Выберите заказчика",
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = false,
                                    leadingIcon = {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(client?.colorHex?.let { safeParseColor(it) } ?: MaterialTheme.colorScheme.primary)
                                        )
                                    },
                                    trailingIcon = {
                                        val arrowRotation by animateFloatAsState(
                                            targetValue = if (manualDropdownExpanded) 180f else 0f,
                                            label = "ArrowRotation"
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = "Dropdown Arrow",
                                            modifier = Modifier.rotate(arrowRotation),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                        disabledBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                        disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        disabledContainerColor = Color.Transparent
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { manualDropdownExpanded = true },
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Buttons aligned by width
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showManualAddDialog = false },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text("Отмена")
                            }

                            Button(
                                onClick = {
                                    val client = clients.find { it.id == selectedClientId }
                                    val durationMs = (manualHours * 3600L + manualMinutes * 60L) * 1000L
                                    if (client != null && durationMs > 0) {
                                        val calendar = Calendar.getInstance()
                                        calendar.timeInMillis = manualDateMs
                                        calendar.set(Calendar.HOUR_OF_DAY, manualStartHours)
                                        calendar.set(Calendar.MINUTE, manualStartMinutes)
                                        calendar.set(Calendar.SECOND, 0)
                                        calendar.set(Calendar.MILLISECOND, 0)
                                        val startTime = calendar.timeInMillis
                                        val endTime = startTime + durationMs
                                        val rate = client.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate

                                        viewModel.addManualEntry(
                                            clientId = client.id,
                                            startTime = startTime,
                                            endTime = endTime,
                                            comment = manualComment.ifBlank { null },
                                            rate = rate
                                        )

                                        // Reset
                                        manualComment = ""
                                        manualHours = 1
                                        manualMinutes = 0
                                        manualDateMs = System.currentTimeMillis()
                                        showManualAddDialog = false
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                enabled = clients.isNotEmpty() && (manualHours > 0 || manualMinutes > 0),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Text("Сохранить", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                InlineClientSelectorSheet(
                    expanded = manualDropdownExpanded,
                    onDismiss = { manualDropdownExpanded = false },
                    clients = clients,
                    selectedClientId = selectedClientId ?: 0L,
                    onClientSelected = { clientId ->
                        selectedClientId = clientId
                        com.example.ui.screens.timer.TimerStateManager.setLastSelectedClientId(clientId)
                        manualDropdownExpanded = false
                    }
                )
            }
        }
    }

    // --- 1. FILTER & SORTING MODAL BOTTOM SHEET ---
    if (showFilterBottomSheet) {
        // Local temporary state variables for applying/resetting inside sheet
        var tempClients by remember { mutableStateOf<Set<Long>>(selectedClients) }
        var tempStatuses by remember { mutableStateOf<Set<TimeEntryStatus>>(selectedStatuses) }
        var tempSortOrder by remember { mutableStateOf<SortOrder>(currentSortOrder) }
        var tempPeriod by remember { mutableStateOf<String>(selectedPeriod) }
        var tempStartDate by remember { mutableStateOf<Long>(customStartDate ?: (System.currentTimeMillis() - 30L * 24 * 3600 * 1000)) }
        var tempEndDate by remember { mutableStateOf<Long>(customEndDate ?: System.currentTimeMillis()) }
        var clientSearchQuery by remember { mutableStateOf("") }

        ModalBottomSheet(
            onDismissRequest = { showFilterBottomSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Title Header
                Text(
                    text = "Фильтры и сортировка",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                // SORTING SECTION
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "СОРТИРОВКА ЗАПИСЕЙ",
                        style = LedgerStyles.UppercaseSectionHeader,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            SortOrder.TIME_DESC to "Новые",
                            SortOrder.TIME_ASC to "Старые"
                        ).forEach { (order, label) ->
                            val isSel = tempSortOrder == order
                            FilterChip(
                                selected = isSel,
                                onClick = { tempSortOrder = order },
                                label = { Text(label, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // PERIOD SECTION
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ВРЕМЕННОЙ ПЕРИОД",
                        style = LedgerStyles.UppercaseSectionHeader,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "ALL" to "Все",
                            "WEEK" to "Неделя",
                            "MONTH" to "Месяц",
                            "CUSTOM" to "Свой"
                        ).forEach { (p, label) ->
                            val isSel = tempPeriod == p
                            FilterChip(
                                selected = isSel,
                                onClick = { tempPeriod = p },
                                label = { Text(label, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    if (tempPeriod == "CUSTOM") {
                        val fmt = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()) }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = fmt.format(Date(tempStartDate)),
                                onValueChange = {},
                                label = { Text("Начало") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = {
                                        showDatePicker(tempStartDate) { tempStartDate = it }
                                    }) {
                                        Icon(Icons.Default.DateRange, contentDescription = "Выбрать дату")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = fmt.format(Date(tempEndDate)),
                                onValueChange = {},
                                label = { Text("Конец") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = {
                                        showDatePicker(tempEndDate) { tempEndDate = it }
                                    }) {
                                        Icon(Icons.Default.DateRange, contentDescription = "Выбрать дату")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }

                // STATUS SECTION
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "СТАТУС ОПЛАТЫ",
                        style = LedgerStyles.UppercaseSectionHeader,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TimeEntryStatus.values().forEach { status ->
                            val label = when (status) {
                                TimeEntryStatus.PAID -> "Оплачено"
                                TimeEntryStatus.INVOICED -> "Счёт"
                                TimeEntryStatus.NOT_PAID -> "Не оплачен"
                            }
                            val isSel = tempStatuses.contains(status)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    tempStatuses = if (isSel) {
                                        tempStatuses.toMutableSet().apply { remove(status) }
                                    } else {
                                        tempStatuses.toMutableSet().apply { add(status) }
                                    }
                                },
                                label = { Text(label, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // CLIENT SELECTION
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "ЗАКАЗЧИКИ",
                        style = LedgerStyles.UppercaseSectionHeader,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = clientSearchQuery,
                        onValueChange = { clientSearchQuery = it },
                        placeholder = { Text("Поиск заказчика...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (clientSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { clientSearchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    val filteredClients = remember(clients, clientSearchQuery) {
                        clients.filter { it.name.contains(clientSearchQuery, ignoreCase = true) }
                    }

                    if (filteredClients.isEmpty()) {
                        Text(
                            text = "Заказчики не найдены",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        // Display list of checkboxes inside a compact column
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                                .verticalScroll(rememberScrollState())
                        ) {
                            filteredClients.forEach { client ->
                                val isChecked = tempClients.contains(client.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            tempClients = if (isChecked) {
                                                tempClients.toMutableSet().apply { remove(client.id) }
                                            } else {
                                                tempClients.toMutableSet().apply { add(client.id) }
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            tempClients = if (checked == false) {
                                                tempClients.toMutableSet().apply { remove(client.id) }
                                            } else {
                                                tempClients.toMutableSet().apply { add(client.id) }
                                            }
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(safeParseColor(client.colorHex))
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = client.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }

                // Action buttons footer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    TextButton(
                        onClick = {
                            tempClients = emptySet()
                            tempStatuses = emptySet()
                            tempSortOrder = SortOrder.TIME_DESC
                            tempPeriod = "MONTH"
                            tempStartDate = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
                            tempEndDate = System.currentTimeMillis()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("СБРОСИТЬ", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.applyFilters(
                                clients = tempClients,
                                statuses = tempStatuses,
                                sort = tempSortOrder,
                                period = tempPeriod,
                                startDate = if (tempPeriod == "CUSTOM") tempStartDate else null,
                                endDate = if (tempPeriod == "CUSTOM") tempEndDate else null
                            )
                            showFilterBottomSheet = false
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("ПРИМЕНИТЬ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // --- 1.5. EXPORT REPORT FOR SELECTED ENTRIES MODAL BOTTOM SHEET ---
    if (showBulkExportBottomSheet) {
        val selectedEntries = remember(entries, selectedEntryIds) {
            entries.filter { selectedEntryIds.contains(it.id) }
        }
        val totalAmount = selectedEntries.sumOf { it.amount }
        val totalSeconds = selectedEntries.sumOf { it.durationSeconds }
        val hoursStr = String.format(Locale.US, "%.2f", totalSeconds / 3600.0)

        ModalBottomSheet(
            onDismissRequest = {
                showBulkExportBottomSheet = false
                bulkExportSuccessCard = false
            },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Title Header
                Text(
                    text = "Экспорт отчёта по выбранным",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                if (!bulkExportSuccessCard) {
                    // Selected Entries Summary Card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Выбрано записей: ${selectedEntries.size}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Время: $hoursStr ч",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "${String.format(Locale.US, "%.2f", totalAmount)} ${settings.currency}",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // FORMAT SELECTION
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ФОРМАТ ЭКСПОРТА",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { bulkExportFormat = "XLSX" },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (bulkExportFormat == "XLSX") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (bulkExportFormat == "XLSX") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            ) {
                                Icon(Icons.Default.GridOn, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Excel (XLSX)")
                            }

                            Button(
                                onClick = { bulkExportFormat = "PDF" },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (bulkExportFormat == "PDF") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (bulkExportFormat == "PDF") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("PDF Отчёт")
                            }
                        }
                    }

                    // COLUMNS SELECTION (FOR XLSX)
                    if (bulkExportFormat == "XLSX") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "СТОЛБЦЫ В EXCEL",
                                style = LedgerStyles.UppercaseSectionHeader,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    .padding(8.dp)
                            ) {
                                XlsxColumn.values().forEach { col ->
                                    val isChecked = bulkExportSelectedXlsxColumns.contains(col)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                if (isChecked) {
                                                    if (bulkExportSelectedXlsxColumns.size > 1) {
                                                        bulkExportSelectedXlsxColumns.remove(col)
                                                    }
                                                } else {
                                                    bulkExportSelectedXlsxColumns.add(col)
                                                }
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    bulkExportSelectedXlsxColumns.add(col)
                                                } else if (bulkExportSelectedXlsxColumns.size > 1) {
                                                    bulkExportSelectedXlsxColumns.remove(col)
                                                }
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        val colLabel = when (col) {
                                            XlsxColumn.DATE -> "Дата"
                                            XlsxColumn.CLIENT -> "Заказчик"
                                            XlsxColumn.COMMENT -> "Описание"
                                            XlsxColumn.SUM -> "Сумма"
                                            else -> col.title
                                        }
                                        Text(
                                            text = colLabel,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // GENERATE BUTTON
                    Button(
                        onClick = {
                            if (selectedEntries.isEmpty()) {
                                android.widget.Toast.makeText(context, "Нет выбранных записей!", android.widget.Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val dateString = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                            val distinctClientIds = selectedEntries.map { it.clientId }.distinct()
                            val clientNames = if (distinctClientIds.size == 1) {
                                clients.find { it.id == distinctClientIds.first() }?.name ?: "Выбранные записи"
                            } else {
                                "Выбранные записи (${distinctClientIds.size} заказч.)"
                            }
                            val dateFmt = SimpleDateFormat("dd.MM.yy", Locale.getDefault())
                            val minDate = selectedEntries.minOfOrNull { it.startTime } ?: System.currentTimeMillis()
                            val maxDate = selectedEntries.maxOfOrNull { it.startTime } ?: System.currentTimeMillis()
                            val periodLabel = if (dateFmt.format(Date(minDate)) == dateFmt.format(Date(maxDate))) {
                                dateFmt.format(Date(minDate))
                            } else {
                                "${dateFmt.format(Date(minDate))} — ${dateFmt.format(Date(maxDate))}"
                            }

                            if (bulkExportFormat == "XLSX") {
                                generatedFileBytes = XlsxGenerator.generateXlsx(
                                    entries = selectedEntries,
                                    clients = clients,
                                    selectedColumns = bulkExportSelectedXlsxColumns.toList(),
                                    currencySymbol = settings.currency,
                                    clientNames = clientNames,
                                    periodLabel = periodLabel,
                                    settings = settings
                                )
                                generatedFileName = "Selected_Report_$dateString.xlsx"
                                generatedMimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            } else {
                                generatedFileBytes = PdfGenerator.generatePdf(
                                    entries = selectedEntries,
                                    clients = clients,
                                    selectedClientNames = clientNames,
                                    periodLabel = periodLabel,
                                    currencySymbol = settings.currency
                                )
                                generatedFileName = "Selected_Invoice_$dateString.pdf"
                                generatedMimeType = "application/pdf"
                            }

                            generatedFileBytes?.let { bytes ->
                                viewModel.saveGeneratedReport(
                                    context = context,
                                    clientNames = clientNames,
                                    periodLabel = periodLabel,
                                    exportFormat = bulkExportFormat,
                                    entries = selectedEntries,
                                    generatedFileBytes = bytes,
                                    fileName = generatedFileName
                                )
                            }

                            bulkExportSuccessCard = true
                            selectedEntryIds = emptySet()
                            android.widget.Toast.makeText(context, "Отчёт успешно сгенерирован!", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Assessment, contentDescription = "Экспортировать")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("СГЕНЕРИРОВАТЬ ОТЧЁТ", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Success View Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(52.dp)
                        )
                        Text(
                            text = "Отчёт по выбранным записям готов!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = generatedFileName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalIconButton(
                                onClick = {
                                    try {
                                        generatedFileBytes?.let { bytes ->
                                            val cacheFile = File(context.cacheDir, generatedFileName)
                                            cacheFile.writeBytes(bytes)
                                            val authority = "${context.packageName}.fileprovider"
                                            val uri = FileProvider.getUriForFile(context, authority, cacheFile)

                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = generatedMimeType
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Поделиться отчётом"))
                                        }
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(context, "Ошибка при шаринге: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(50.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = "Поделиться")
                            }

                            Button(
                                onClick = { createDocLauncher.launch(generatedFileName) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("СОХРАНИТЬ В ФАЙЛЫ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // --- 2. EXPORT REPORTS MODAL BOTTOM SHEET ---
    if (showExportBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = {
                showExportBottomSheet = false
                showExportSuccessCard = false
                generatedFileBytes = null
            },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Title Header
                Text(
                    text = "Экспорт отчётов",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                if (!showExportSuccessCard) {
                    // FORMAT SELECTION
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ФОРМАТ ЭКСПОРТА",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { exportFormat = "XLSX" },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (exportFormat == "XLSX") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (exportFormat == "XLSX") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            ) {
                                Icon(Icons.Default.GridOn, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Excel (XLSX)")
                            }

                            Button(
                                onClick = { exportFormat = "PDF" },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (exportFormat == "PDF") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = if (exportFormat == "PDF") MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Счёт (PDF)")
                            }
                        }
                    }

                    // PERIOD PRESET
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ПЕРИОД ВЫГРУЗКИ",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "ALL" to "Все",
                                "WEEK" to "Неделя",
                                "MONTH" to "Месяц",
                                "CUSTOM" to "Свой"
                            ).forEach { (p, label) ->
                                val isSel = exportPeriodPreset == p
                                FilterChip(
                                    selected = isSel,
                                    onClick = { exportPeriodPreset = p },
                                    label = { Text(label, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (exportPeriodPreset == "CUSTOM") {
                            val fmt = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()) }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = fmt.format(Date(exportCustomStartDate)),
                                    onValueChange = {},
                                    label = { Text("Начало") },
                                    readOnly = true,
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            showDatePicker(exportCustomStartDate) { exportCustomStartDate = it }
                                        }) {
                                            Icon(Icons.Default.DateRange, contentDescription = "Выбрать дату")
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = fmt.format(Date(exportCustomEndDate)),
                                    onValueChange = {},
                                    label = { Text("Конец") },
                                    readOnly = true,
                                    trailingIcon = {
                                        IconButton(onClick = {
                                            showDatePicker(exportCustomEndDate) { exportCustomEndDate = it }
                                        }) {
                                            Icon(Icons.Default.DateRange, contentDescription = "Выбрать дату")
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }

                    // CLIENT CHIPS/CHECKLIST FOR EXPORT
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ФИЛЬТР ПО ЗАКАЗЧИКАМ",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (clients.isEmpty()) {
                            Text("Нет созданных заказчиков", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val allSelected = exportSelectedClients.isEmpty()
                                FilterChip(
                                    selected = allSelected,
                                    onClick = { exportSelectedClients.clear() },
                                    label = { Text("Все заказчики") }
                                )
                                clients.forEach { c ->
                                    val isChecked = exportSelectedClients.contains(c.id)
                                    FilterChip(
                                        selected = isChecked,
                                        onClick = {
                                            if (isChecked) {
                                                exportSelectedClients.remove(c.id)
                                            } else {
                                                exportSelectedClients.add(c.id)
                                            }
                                        },
                                        label = {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(safeParseColor(c.colorHex)))
                                                Text(c.name)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // STATUS FILTER FOR EXPORT
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "ФИЛЬТР ПО СТАТУСАМ",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TimeEntryStatus.values().forEach { status ->
                                val isChecked = exportSelectedStatuses.contains(status)
                                val label = when (status) {
                                    TimeEntryStatus.NOT_PAID -> "Не оплачен"
                                    TimeEntryStatus.INVOICED -> "Счёт выставлен"
                                    TimeEntryStatus.PAID -> "Оплачено"
                                }
                                FilterChip(
                                    selected = isChecked,
                                    onClick = {
                                        if (isChecked) {
                                            if (exportSelectedStatuses.size > 1) {
                                                exportSelectedStatuses.remove(status)
                                            }
                                        } else {
                                            exportSelectedStatuses.add(status)
                                        }
                                    },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }

                    // XLSX COLUMNS SELECTION (Visible only if XLSX)
                    if (exportFormat == "XLSX") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "КОЛОНКИ ТАБЛИЦЫ EXCEL",
                                style = LedgerStyles.UppercaseSectionHeader,
                                color = MaterialTheme.colorScheme.primary
                            )
                            @OptIn(ExperimentalLayoutApi::class)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                XlsxColumn.values().filter { it != XlsxColumn.CLIENT }.forEach { col ->
                                    val isChecked = exportSelectedXlsxColumns.contains(col)
                                    val label = when (col) {
                                        XlsxColumn.DATE -> "Дата"
                                        XlsxColumn.CLIENT -> "Заказчик"
                                        XlsxColumn.COMMENT -> "Описание"
                                        XlsxColumn.SUM -> "Сумма"
                                    }
                                    FilterChip(
                                        selected = isChecked,
                                        onClick = {
                                            if (isChecked) {
                                                if (exportSelectedXlsxColumns.size > 1) {
                                                    exportSelectedXlsxColumns.remove(col)
                                                }
                                            } else {
                                                exportSelectedXlsxColumns.add(col)
                                            }
                                        },
                                        label = { Text(label, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // GENERATE BUTTON
                    Button(
                        onClick = {
                            val filtered = entries.filter { entry ->
                                val matchesClient = if (exportSelectedClients.isEmpty()) true else exportSelectedClients.contains(entry.clientId)
                                val matchesStatus = exportSelectedStatuses.contains(entry.status)
                                val matchesPeriod = when (exportPeriodPreset) {
                                    "WEEK" -> {
                                        val cal = Calendar.getInstance()
                                        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
                                        cal.set(Calendar.HOUR_OF_DAY, 0)
                                        cal.set(Calendar.MINUTE, 0)
                                        cal.set(Calendar.SECOND, 0)
                                        cal.set(Calendar.MILLISECOND, 0)
                                        entry.startTime >= cal.timeInMillis
                                    }
                                    "MONTH" -> {
                                        val cal = Calendar.getInstance()
                                        cal.set(Calendar.DAY_OF_MONTH, 1)
                                        cal.set(Calendar.HOUR_OF_DAY, 0)
                                        cal.set(Calendar.MINUTE, 0)
                                        cal.set(Calendar.SECOND, 0)
                                        cal.set(Calendar.MILLISECOND, 0)
                                        entry.startTime >= cal.timeInMillis
                                    }
                                    "CUSTOM" -> {
                                        entry.startTime in exportCustomStartDate..exportCustomEndDate
                                    }
                                    else -> true
                                }
                                matchesClient && matchesStatus && matchesPeriod
                            }

                            if (filtered.isEmpty()) {
                                android.widget.Toast.makeText(context, "Нет записей по выбранным критериям!", android.widget.Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val dateString = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                            val clientNames = if (exportSelectedClients.isEmpty()) {
                                val distinctClientIds = filtered.map { it.clientId }.distinct()
                                if (distinctClientIds.size == 1) {
                                    clients.find { it.id == distinctClientIds.first() }?.name ?: "Все заказчики"
                                } else {
                                    "Все заказчики"
                                }
                            } else {
                                clients.filter { exportSelectedClients.contains(it.id) }.joinToString { it.name }
                            }
                            val periodLabel = when (exportPeriodPreset) {
                                "ALL" -> "За весь период"
                                "WEEK" -> "За эту неделю"
                                "MONTH" -> "За этот месяц"
                                "CUSTOM" -> {
                                    val fmt = SimpleDateFormat("dd.MM.yy", Locale.getDefault())
                                    "${fmt.format(Date(exportCustomStartDate))} — ${fmt.format(Date(exportCustomEndDate))}"
                                }
                                else -> "За весь период"
                            }

                            if (exportFormat == "XLSX") {
                                generatedFileBytes = XlsxGenerator.generateXlsx(
                                    entries = filtered,
                                    clients = clients,
                                    selectedColumns = exportSelectedXlsxColumns.toList(),
                                    currencySymbol = settings.currency,
                                    clientNames = clientNames,
                                    periodLabel = periodLabel,
                                    settings = settings
                                )
                                generatedFileName = "Timesheet_Export_$dateString.xlsx"
                                generatedMimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            } else {
                                generatedFileBytes = PdfGenerator.generatePdf(
                                    entries = filtered,
                                    clients = clients,
                                    selectedClientNames = clientNames,
                                    periodLabel = periodLabel,
                                    currencySymbol = settings.currency
                                )
                                generatedFileName = "Invoice_Export_$dateString.pdf"
                                generatedMimeType = "application/pdf"
                            }

                            generatedFileBytes?.let { bytes ->
                                viewModel.saveGeneratedReport(
                                    context = context,
                                    clientNames = clientNames,
                                    periodLabel = periodLabel,
                                    exportFormat = exportFormat,
                                    entries = filtered,
                                    generatedFileBytes = bytes,
                                    fileName = generatedFileName
                                )
                            }

                            showExportSuccessCard = true
                            android.widget.Toast.makeText(context, "Отчёт успешно сгенерирован!", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Assessment, contentDescription = "Экспортировать")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("СГЕНЕРИРОВАТЬ ОТЧЁТ", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Success View Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(52.dp)
                        )
                        Text(
                            text = "Отчёт готов!",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = generatedFileName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalIconButton(
                                onClick = {
                                    try {
                                        generatedFileBytes?.let { bytes ->
                                            val cacheFile = File(context.cacheDir, generatedFileName)
                                            cacheFile.writeBytes(bytes)
                                            val authority = "${context.packageName}.fileprovider"
                                            val uri = FileProvider.getUriForFile(context, authority, cacheFile)

                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = generatedMimeType
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Поделиться отчётом"))
                                        }
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(context, "Ошибка при шаринге: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(50.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = "Поделиться")
                            }

                            Button(
                                onClick = { createDocLauncher.launch(generatedFileName) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Save, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("СОХРАНИТЬ В ФАЙЛЫ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // --- 3. REPORTS HISTORY BOTTOM SHEET ---
    if (showReportsHistoryBottomSheet) {
        ReportsHistoryBottomSheet(
            reports = reportsHistory,
            allTimeEntries = entries,
            currencySymbol = settings.currency,
            onDismiss = { showReportsHistoryBottomSheet = false },
            onShareReport = { report ->
                shareReportFile(context, report.filePath, report.fileName, if (report.exportFormat == "XLSX") "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" else "application/pdf")
            },
            onConfirmPayment = { report ->
                selectedReportForPayment = report
            },
            onDeleteReport = { report ->
                viewModel.deleteReport(report)
            }
        )
    }

    // --- 4. CONFIRM PAYMENT DIALOG ---
    selectedReportForPayment?.let { report ->
        ConfirmPaymentDialog(
            report = report,
            currencySymbol = settings.currency,
            onDismiss = { selectedReportForPayment = null },
            onConfirm = { photoUri, notes ->
                viewModel.confirmReportPayment(report, photoUri, notes)
                android.widget.Toast.makeText(context, "Оплата подтверждена! Записи переведены в статус «Оплачен»", android.widget.Toast.LENGTH_SHORT).show()
                selectedReportForPayment = null
            }
        )
    }

    // --- 5. REPORT DETAILS DIALOG ---
    selectedReportForDetails?.let { report ->
        ReportDetailsDialog(
            report = report,
            allEntries = entries,
            currencySymbol = settings.currency,
            onDismiss = { selectedReportForDetails = null },
            onShare = {
                shareReportFile(context, report.filePath, report.fileName, if (report.exportFormat == "XLSX") "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" else "application/pdf")
            },
            onConfirmPayment = {
                selectedReportForPayment = report
                selectedReportForDetails = null
            },
            onDelete = {
                viewModel.deleteReport(report)
                selectedReportForDetails = null
            }
        )
    }
}

fun getRecordsPluralString(count: Int): String {
    val mod10 = count % 10
    val mod100 = count % 100
    return when {
        mod100 in 11..14 -> "$count записей"
        mod10 == 1 -> "$count запись"
        mod10 in 2..4 -> "$count записи"
        else -> "$count записей"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InlineClientSelectorSheet(
    expanded: Boolean,
    onDismiss: () -> Unit,
    clients: List<Client>,
    selectedClientId: Long,
    onClientSelected: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (expanded) {
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Выберите заказчика",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    clients.forEach { client ->
                        val isSelected = selectedClientId == client.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    else Color.Transparent
                                )
                                .clickable {
                                    onClientSelected(client.id)
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(safeParseColor(client.colorHex))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = client.name,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

fun shareReportFile(context: android.content.Context, filePath: String, fileName: String, mimeType: String) {
    try {
        val file = File(filePath)
        if (!file.exists()) {
            android.widget.Toast.makeText(context, "Файл не найден на устройстве", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val authority = "${context.packageName}.fileprovider"
        val contentUri = FileProvider.getUriForFile(context, authority, file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Скачать / Отправить отчёт"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Ошибка при открытии файла: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsHistoryBottomSheet(
    reports: List<Report>,
    allTimeEntries: List<TimeEntry>,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onShareReport: (Report) -> Unit,
    onConfirmPayment: (Report) -> Unit,
    onDeleteReport: (Report) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Title Header (matching Export Reports)
            Text(
                text = "История отчётов",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            if (reports.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "История отчётов пуста",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Сгенерированные отчёты будут сохраняться здесь.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 520.dp),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(reports, key = { it.id }) { report ->
                        ReportItemCard(
                            report = report,
                            currencySymbol = currencySymbol,
                            onShare = { onShareReport(report) },
                            onConfirmPayment = { onConfirmPayment(report) },
                            onDelete = { onDeleteReport(report) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReportItemCard(
    report: Report,
    currencySymbol: String,
    onShare: () -> Unit,
    onConfirmPayment: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("ru")) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header row: format tag + date on left (aligned to margin), status badge on right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = report.exportFormat,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = dateFmt.format(Date(report.createdAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status badge
                val isPaid = report.status == ReportStatus.PAID
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isPaid) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFE65100).copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.Schedule,
                            contentDescription = null,
                            tint = if (isPaid) Color(0xFF4CAF50) else Color(0xFFFF9800),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = if (isPaid) "Оплачен" else "Счёт выставлен",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isPaid) Color(0xFF81C784) else Color(0xFFFFB74D)
                        )
                    }
                }
            }

            // Client & Period Group (In one row: Client left, Period right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = report.clientNames,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = report.periodLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Clean Stats Inline Bar (Aligned directly to left margin, generous spacing)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(36.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Сумма",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatCurrency(report.totalAmount, currencySymbol),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Время",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = formatHours(report.totalDurationSeconds),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Записей",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${report.entriesCount}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (report.status == ReportStatus.INVOICED) {
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier
                            .size(42.dp)
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(10.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Скачать отчёт",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Button(
                        onClick = onConfirmPayment,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("Оплачено", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                } else {
                    Button(
                        onClick = onShare,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Скачать отчёт",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ConfirmPaymentDialog(
    report: Report,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onConfirm: (photoUri: String?, notes: String?) -> Unit
) {
    val context = LocalContext.current
    var photoUriString by remember { mutableStateOf<String?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            photoUriString = it.toString()
        }
    }

    val imageBitmap = remember(photoUriString) {
        if (photoUriString != null) {
            try {
                val uri = Uri.parse(photoUriString)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            } catch (_: Exception) {
                null
            }
        } else null
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Подтвердить оплату",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                // Info Summary - Flush to left, no card background
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = report.clientNames,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = report.periodLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = formatCurrency(report.totalAmount, currencySymbol),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Photo picker section
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Чек / Фото перевода (необязательно):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (imageBitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = imageBitmap,
                                contentDescription = "Чек оплаты",
                                modifier = Modifier.fillMaxSize()
                            )
                            IconButton(
                                onClick = { photoUriString = null },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                    .size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Удалить фото",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { photoLauncher.launch("image/*") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Приложить фото / чек")
                        }
                    }
                }

                // Action Buttons (Confirm takes all available width)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(44.dp)
                    ) {
                        Text("Отмена", style = MaterialTheme.typography.labelLarge)
                    }

                    Button(
                        onClick = {
                            onConfirm(photoUriString, null)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Подтвердить", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold))
                    }
                }

                // Notice text placed BELOW buttons, with dark/muted secondary color
                Text(
                    text = "Подтверждение перевода средств переведёт все записи этого отчёта в статус «Оплачен».",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun ReportDetailsDialog(
    report: Report,
    allEntries: List<TimeEntry>,
    currencySymbol: String,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onConfirmPayment: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val dateFmt = remember { SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale("ru")) }

    val includedEntryIds = remember(report.entryIdsJson) {
        val rawJson = report.entryIdsJson.trim().removePrefix("[").removeSuffix("]")
        if (rawJson.isNotBlank()) {
            rawJson.split(",").mapNotNull { it.trim().toLongOrNull() }.toSet()
        } else emptySet()
    }

    val reportEntries = remember(allEntries, includedEntryIds) {
        allEntries.filter { includedEntryIds.contains(it.id) }
    }

    val paymentBitmap = remember(report.paymentPhotoUri) {
        if (report.paymentPhotoUri != null) {
            try {
                val uri = Uri.parse(report.paymentPhotoUri)
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            } catch (_: Exception) {
                null
            }
        } else null
    }

    var showDeleteConfirm by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Детали отчёта",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Закрыть")
                    }
                }

                // Status banner
                val isPaid = report.status == ReportStatus.PAID
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isPaid) Color(0xFFE8F5E9) else Color(0xFFFFF3E0),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isPaid) Icons.Default.CheckCircle else Icons.Default.Schedule,
                            contentDescription = null,
                            tint = if (isPaid) Color(0xFF2E7D32) else Color(0xFFE65100)
                        )
                        Column {
                            Text(
                                text = if (isPaid) "Статус: ОПЛАЧЕН" else "Статус: СЧЁТ ВЫСТАВЛЕН",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isPaid) Color(0xFF2E7D32) else Color(0xFFE65100)
                            )
                            if (isPaid && report.paymentConfirmedAt != null) {
                                Text(
                                    text = "Оплачено: ${dateFmt.format(Date(report.paymentConfirmedAt))}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }
                }

                // General Info
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Заказчик: ${report.clientNames}", fontWeight = FontWeight.SemiBold)
                    Text("Период: ${report.periodLabel}", style = MaterialTheme.typography.bodyMedium)
                    Text("Дата создания: ${dateFmt.format(Date(report.createdAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Формат: ${report.exportFormat} (${report.fileName})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Итоговая сумма: ${formatCurrency(report.totalAmount, currencySymbol)}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                }

                // Payment receipt photo if present
                if (paymentBitmap != null) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Чек / Фото перевода:", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = paymentBitmap,
                                contentDescription = "Чек перевода",
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        if (!report.paymentNotes.isNullOrBlank()) {
                            Text("Комментарий: ${report.paymentNotes}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Included entries list
                if (reportEntries.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Записи в отчёте (${reportEntries.size}):",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        reportEntries.forEach { entry ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = entry.comment?.ifBlank { null } ?: "Без комментария",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = formatHours(entry.durationSeconds),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = formatCurrency(entry.amount, currencySymbol),
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Actions
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onShare,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Скачать / Поделиться отчётом")
                    }

                    if (report.status == ReportStatus.INVOICED) {
                        Button(
                            onClick = onConfirmPayment,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Подтвердить оплату")
                        }
                    }

                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Удалить из истории")
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Удалить отчёт из истории?") },
            text = { Text("Запись об отчёте и сохранённый файл будут удалены из истории.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDelete()
                        showDeleteConfirm = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirm = false },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Отмена")
                }
            }
        )
    }
}

