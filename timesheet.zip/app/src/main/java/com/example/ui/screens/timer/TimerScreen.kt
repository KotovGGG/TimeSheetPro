package com.example.ui.screens.timer

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.rotate
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import com.example.TimeSheetApp
import com.example.data.local.entity.AmountRoundingMode
import com.example.data.local.entity.AppSettings
import com.example.data.local.entity.Client
import com.example.data.local.entity.TimeEntry
import com.example.data.local.entity.TimeEntryStatus
import com.example.ui.AppViewModelProvider
import com.example.ui.theme.LedgerStyles
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerScreen(
    modifier: Modifier = Modifier,
    viewModel: TimerViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val context = LocalContext.current
    val activeClients by viewModel.activeClients.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val timerState by viewModel.timerState.collectAsState()
    val elapsedSeconds by viewModel.elapsedSeconds.collectAsState()
    val pauseSeconds by viewModel.pauseSeconds.collectAsState()
    val allEntries by viewModel.allTimeEntries.collectAsState()
    val showConfirmDialog by TimerStateManager.showConfirmDialog.collectAsState()

    var selectedClientId by remember { mutableStateOf<Long?>(null) }
    var taskComment by remember { mutableStateOf("") }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var showManualDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Auto-select last selected client (or first client) if none selected
    LaunchedEffect(activeClients) {
        if (selectedClientId == null && activeClients.isNotEmpty()) {
            val lastId = TimerStateManager.getLastSelectedClientId()
            val hasLastActive = lastId != null && activeClients.any { it.id == lastId }
            selectedClientId = if (hasLastActive) lastId else activeClients.first().id
        }
    }

    // Live calculation of current session earnings
    val activeClient = activeClients.find { it.id == timerState.clientId }
    val appliedRate = activeClient?.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate
    val liveEarnings = (elapsedSeconds.toDouble() / 3600.0) * appliedRate

    // Today's total hours and earnings
    val todayStartMs = remember {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.timeInMillis
    }

    val todayEntries = allEntries.filter { it.startTime >= todayStartMs && it.endTime != null }
    val todayTotalSeconds = todayEntries.sumOf { it.durationSeconds }
    val todayTotalEarnings = todayEntries.sumOf { it.amount }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            val parentHeight = maxHeight
            val parentWidth = maxWidth
            val dialSize = if (parentWidth - 40.dp < parentHeight - 280.dp) {
                parentWidth - 40.dp
            } else {
                parentHeight - 280.dp
            }.coerceIn(160.dp, 320.dp)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp)
                    .heightIn(min = parentHeight - 32.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // --- Today's Ledger Summary Card ---
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("summary_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "СВОДКА ЗА СЕГОДНЯ",
                            style = LedgerStyles.UppercaseSectionHeader,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = "ОТРАБОТАНО",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Start
                                )
                                Text(
                                    text = formatHours(todayTotalSeconds),
                                    style = LedgerStyles.MonospaceNumberMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(top = 2.dp),
                                    textAlign = TextAlign.Start
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 16.dp)
                                    .width(1.dp)
                                    .height(36.dp)
                                    .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = "ЗАРАБОТАНО",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Start
                                )
                                Text(
                                    text = formatCurrency(todayTotalEarnings, settings.currency),
                                    style = LedgerStyles.MonospaceNumberMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(top = 2.dp),
                                    textAlign = TextAlign.Start
                                )
                            }
                        }
                    }
                }

                // --- Central Circular Ring Dial and Live Status ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .testTag("timer_card"),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                    // The Circular Dial
                    val clientColor = MaterialTheme.colorScheme.primary
                    TimerDial(
                        elapsedSeconds = elapsedSeconds,
                        clientColor = clientColor,
                        isRunning = timerState.status == TimerStatus.RUNNING,
                        dialSize = dialSize,
                        pauseSeconds = if (timerState.status != TimerStatus.IDLE) pauseSeconds else null,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }

            Spacer(modifier = Modifier.weight(1f))

            // --- State-Dependent Control Actions ---
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (timerState.status) {
                    TimerStatus.IDLE -> {
                        // Start tracking button
                        Button(
                            onClick = {
                                viewModel.startTimer(context, selectedClientId)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("control_timer_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Start")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Старт", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        // Manual entry action
                        OutlinedButton(
                            onClick = { showManualDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("manual_entry_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Manual Entry")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Добавить запись вручную", fontWeight = FontWeight.Medium)
                        }
                    }

                    TimerStatus.RUNNING -> {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { viewModel.pauseTimer(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("pause_timer_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = MaterialTheme.colorScheme.onSecondary
                                )
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = "Pause")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Пауза", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Button(
                                onClick = {
                                    TimerStateManager.setShowConfirmDialog(true)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("stop_timer_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                )
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = "Finish")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Завершить", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }

                    TimerStatus.PAUSED -> {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { viewModel.resumeTimer(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("resume_timer_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Continue")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Продолжить", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            Button(
                                onClick = {
                                    TimerStateManager.setShowConfirmDialog(true)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("stop_timer_button"),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                )
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = "Finish")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Завершить", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

    // --- Add Manual Record Dialog ---
    if (showManualDialog) {
        AddManualRecordDialog(
            activeClients = activeClients,
            onDismiss = { showManualDialog = false },
            onSave = { clientId, startTimeMs, endTimeMs, durationSeconds, comment ->
                showManualDialog = false
                val app = context.applicationContext as TimeSheetApp
                insertManualEntry(
                    clientId = clientId,
                    startTimeMs = startTimeMs,
                    endTimeMs = endTimeMs,
                    durationSeconds = durationSeconds,
                    comment = comment,
                    scope = coroutineScope,
                    app = app,
                    onSuccess = {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Запись успешно добавлена")
                        }
                    },
                    onError = { errorMsg ->
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Ошибка: $errorMsg")
                        }
                    }
                )
            }
        )
    }

    // --- Confirm Finish Recording Dialog ---
    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { TimerStateManager.setShowConfirmDialog(false) },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            title = { Text("Завершить запись?", fontWeight = FontWeight.Bold) },
            text = { Text("Вы действительно хотите завершить текущую сессию записи времени?") },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { TimerStateManager.setShowConfirmDialog(false) }
                    ) {
                        Text("Продолжить")
                    }
                    Button(
                        onClick = {
                            TimerStateManager.setShowConfirmDialog(false)
                            viewModel.stopTimer(context)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        )
                    ) {
                        Text("Завершить")
                    }
                }
            },
            dismissButton = null
        )
    }

    // --- Save Tracked Session Dialog ---
    timerState.pendingSaveDuration?.let { pendingSeconds ->
        SaveSessionDialog(
            elapsedSeconds = pendingSeconds,
            pauseSeconds = timerState.pendingSavePauseDuration ?: 0L,
            initialClientId = timerState.clientId,
            initialComment = timerState.comment,
            activeClients = activeClients,
            globalHourlyRate = settings.globalHourlyRate,
            currency = settings.currency,
            onDismiss = {
                TimerStateManager.clearPending()
            },
            onSave = { clientId, comment, hourlyRate, finalDurationSeconds ->
                TimerStateManager.clearPending()
                val app = context.applicationContext as TimeSheetApp
                saveTrackedSessionEntry(
                    clientId = clientId,
                    comment = comment,
                    rate = hourlyRate,
                    durationSeconds = finalDurationSeconds,
                    scope = coroutineScope,
                    app = app,
                    settings = settings,
                    onSuccess = {
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Сессия успешно сохранена")
                        }
                    }
                )
            }
        )
    }
}

@Composable
fun TimerDial(
    elapsedSeconds: Long,
    clientColor: Color,
    isRunning: Boolean = false,
    dialSize: Dp = 280.dp,
    pauseSeconds: Long? = null,
    modifier: Modifier = Modifier
) {
    val fontSizeScale = (dialSize.value * 0.15f).sp
    val pauseFontSizeScale = (dialSize.value * 0.07f).sp

    Box(
        modifier = modifier.size(dialSize),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val maxStrokePx = 24.dp.toPx()
            val strokeWidthPx = 14.dp.toPx()
            val diameter = size.minDimension - maxStrokePx
            val radius = diameter / 2f
            val centerOffset = Offset(size.width / 2f, size.height / 2f)

            // Outer Ring (brighter when running, dimmer when paused/idle)
            val circleAlpha = if (isRunning) 1.0f else 0.35f
            drawCircle(
                color = clientColor.copy(alpha = circleAlpha),
                radius = radius,
                center = centerOffset,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidthPx)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = formatDuration(elapsedSeconds),
                style = LedgerStyles.MonospaceNumberLarge.copy(
                    fontSize = fontSizeScale,
                    fontWeight = FontWeight.Bold,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
            
            if (pauseSeconds != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = formatDuration(pauseSeconds),
                    style = LedgerStyles.MonospaceNumberLarge.copy(
                        fontSize = pauseFontSizeScale,
                        fontWeight = FontWeight.Normal,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddManualRecordDialog(
    activeClients: List<Client>,
    onDismiss: () -> Unit,
    onSave: (clientId: Long, startTimeMs: Long, endTimeMs: Long, durationSeconds: Long, comment: String) -> Unit
) {
    var selectedId by remember { 
        val lastId = TimerStateManager.getLastSelectedClientId()
        val defaultId = if (lastId != null && activeClients.any { it.id == lastId }) lastId else activeClients.firstOrNull()?.id ?: -1L
        mutableStateOf(defaultId) 
    }

    LaunchedEffect(activeClients) {
        if (selectedId == -1L && activeClients.isNotEmpty()) {
            val lastId = TimerStateManager.getLastSelectedClientId()
            val defaultId = if (lastId != null && activeClients.any { it.id == lastId }) lastId else activeClients.first().id
            selectedId = defaultId
        }
    }

    var comment by remember { mutableStateOf("") }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    
    var hours by remember { mutableStateOf(1) }
    var minutes by remember { mutableStateOf(0) }
    var manualDateMs by remember { mutableStateOf(System.currentTimeMillis()) }

    val calNow = Calendar.getInstance()
    var manualStartHours by remember { mutableStateOf(calNow.get(Calendar.HOUR_OF_DAY)) }
    var manualStartMinutes by remember { mutableStateOf(calNow.get(Calendar.MINUTE)) }
    var showManualStartTimePicker by remember { mutableStateOf(false) }
    val formattedStartTime = String.format(Locale.US, "%02d:%02d", manualStartHours, manualStartMinutes)

    val context = LocalContext.current
    val displayFormatter = remember { SimpleDateFormat("d MMMM, yyyy", Locale("ru")) }

    var showDatePickerState by remember { mutableStateOf(false) }
    var datePickerInitialTime by remember { mutableStateOf(0L) }
    var onDateSelectedCallback by remember { mutableStateOf<((Long) -> Unit)?>(null) }

    fun showDatePicker(initialTime: Long, onDateSelected: (Long) -> Unit) {
        datePickerInitialTime = initialTime
        onDateSelectedCallback = onDateSelected
        showDatePickerState = true
    }

    if (showDatePickerState && onDateSelectedCallback != null) {
        ComposeDatePickerDialog(
            initialTimeMs = datePickerInitialTime,
            onDismissRequest = { showDatePickerState = false },
            onDateSelected = { selectedDate ->
                onDateSelectedCallback?.invoke(selectedDate)
            }
        )
    }

    if (showManualStartTimePicker) {
        val startTimePickerState = rememberTimePickerState(
            initialHour = manualStartHours,
            initialMinute = manualStartMinutes,
            is24Hour = true
        )
        
        TimePickerDialog(
            onDismissRequest = { showManualStartTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        manualStartHours = startTimePickerState.hour
                        manualStartMinutes = startTimePickerState.minute
                        showManualStartTimePicker = false
                    }
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualStartTimePicker = false }) {
                    Text("Отмена")
                }
            }
        ) {
            MaterialTheme(
                typography = MaterialTheme.typography.copy(
                    bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    ),
                    labelMedium = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp
                    )
                )
            ) {
                TimePicker(
                    state = startTimePickerState,
                    colors = customTimePickerColors()
                )
            }
        }
    }

    if (showTimePicker) {
        val timePickerState = rememberTimePickerState(
            initialHour = hours,
            initialMinute = minutes,
            is24Hour = true
        )
        
        TimePickerDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        hours = timePickerState.hour
                        minutes = timePickerState.minute
                        showTimePicker = false
                    }
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Отмена")
                }
            }
        ) {
            MaterialTheme(
                typography = MaterialTheme.typography.copy(
                    bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    ),
                    labelMedium = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp
                    )
                )
            ) {
                TimePicker(
                    state = timePickerState,
                    colors = customTimePickerColors()
                )
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
        dragHandle = { BottomSheetDefaults.DragHandle() }
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp)
            ) {
                Text(
                    text = "Добавить запись вручную",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                // Combined Date and Start Time Button
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Дата и время начала работы",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = {
                            showDatePicker(manualDateMs) { dateMs ->
                                manualDateMs = dateMs
                                showManualStartTimePicker = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = "Select date and start time",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "${displayFormatter.format(Date(manualDateMs))} в $formattedStartTime",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Work Duration Button (TimePicker Trigger)
                val formattedTime = String.format(Locale.US, "%02d:%02d", hours, minutes)
                Column {
                    Text("Длительность", style = MaterialTheme.typography.labelSmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = { showTimePicker = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Select work time",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Время работы: $formattedTime",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Comment input
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Описание работы / Комментарий") },
                    placeholder = { Text("Например: Разработка API") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    maxLines = 3
                )

                // Client selector inside dialog (moved after comment)
                val currentClient = activeClients.find { it.id == selectedId }
                Column {
                    Text("Заказчик", style = MaterialTheme.typography.labelSmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = currentClient?.name ?: "Выберите заказчика",
                            onValueChange = {},
                            readOnly = true,
                            enabled = false,
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(safeParseColor(currentClient?.colorHex ?: "#EAD5A0"))
                                )
                            },
                            trailingIcon = {
                                val arrowRotation by animateFloatAsState(
                                    targetValue = if (dropdownExpanded) 180f else 0f,
                                    label = "ArrowRotation"
                                )
                                Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown Arrow",
                                        modifier = Modifier.rotate(arrowRotation),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                disabledBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                disabledContainerColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dropdownExpanded = true },
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Action buttons with equal width
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Отмена")
                    }

                    Button(
                        onClick = {
                            if (selectedId != -1L) {
                                val durationSeconds = (hours * 3600 + minutes * 60).toLong()
                                val calendar = Calendar.getInstance()
                                calendar.timeInMillis = manualDateMs
                                calendar.set(Calendar.HOUR_OF_DAY, manualStartHours)
                                calendar.set(Calendar.MINUTE, manualStartMinutes)
                                calendar.set(Calendar.SECOND, 0)
                                calendar.set(Calendar.MILLISECOND, 0)
                                val startTimeMs = calendar.timeInMillis
                                val endTimeMs = startTimeMs + durationSeconds * 1000L
                                onSave(selectedId, startTimeMs, endTimeMs, durationSeconds, comment)
                            }
                        },
                        enabled = selectedId != -1L && (hours > 0 || minutes > 0),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Сохранить", fontWeight = FontWeight.Bold)
                    }
                }
            }
            InlineClientSelectorSheet(
                expanded = dropdownExpanded,
                onDismiss = { dropdownExpanded = false },
                clients = activeClients,
                selectedClientId = selectedId,
                onClientSelected = { clientId ->
                    selectedId = clientId
                    TimerStateManager.setLastSelectedClientId(clientId)
                    dropdownExpanded = false
                }
            )
        }
    }
}

// Format duration to HH:MM:SS
fun formatDuration(totalSeconds: Long): String {
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
}

// Format seconds into decimal hours (e.g., 2.50 hrs)
fun formatHours(totalSeconds: Long): String {
    val hours = totalSeconds.toDouble() / 3600.0
    return String.format(Locale.getDefault(), "%.2f ч", hours)
}

// Format currency using locale
fun formatCurrency(amount: Double, currencyCode: String): String {
    val symbol = when (currencyCode) {
        "USD" -> "$"
        "EUR" -> "€"
        "RUB" -> "₽"
        "GBP" -> "£"
        "KZT" -> "₸"
        "JPY" -> "¥"
        "BYN" -> "Br"
        "CHF" -> "₣"
        else -> currencyCode
    }
    return String.format(Locale.getDefault(), "%.2f %s", amount, symbol)
}

// Safe hex color parser
fun safeParseColor(hexString: String): Color {
    return try {
        val cleanHex = hexString.removePrefix("#")
        val colorInt = if (cleanHex.length == 6) {
            "FF$cleanHex".toLong(16).toInt()
        } else {
            cleanHex.toLong(16).toInt()
        }
        Color(colorInt)
    } catch (e: Exception) {
        Color(0xFFEAD5A0) // Brass accent default
    }
}

fun insertManualEntry(
    clientId: Long,
    startTimeMs: Long,
    endTimeMs: Long,
    durationSeconds: Long,
    comment: String,
    scope: CoroutineScope,
    app: TimeSheetApp,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    scope.launch(Dispatchers.IO) {
        try {
            val settings = app.container.settingsRepository.getSettingsFlow().firstOrNull() ?: AppSettings()
            val clients = app.container.clientRepository.getActiveClients().firstOrNull() ?: emptyList()
            val client = clients.find { it.id == clientId }
            
            // 1. Time rounding UP (ceiling)
            val roundingMinutes = settings.timeRoundingMinutes
            val finalDurationSeconds = if (roundingMinutes > 0) {
                val roundingSeconds = roundingMinutes * 60L
                if (durationSeconds % roundingSeconds == 0L) {
                    durationSeconds
                } else {
                    ((durationSeconds / roundingSeconds) + 1L) * roundingSeconds
                }
            } else {
                durationSeconds
            }
            
            // 2. Applied Rate
            val appliedRate = client?.defaultHourlyRate?.takeIf { it > 0.0 } ?: settings.globalHourlyRate
            
            // 3. Amount & Rounding
            val rawAmount = (finalDurationSeconds.toDouble() / 3600.0) * appliedRate
            val finalAmount = settings.roundAmount(rawAmount)
            
            val entry = TimeEntry(
                clientId = clientId,
                startTime = startTimeMs,
                endTime = endTimeMs,
                durationSeconds = finalDurationSeconds,
                rawDurationSeconds = durationSeconds,
                comment = comment.ifBlank { null },
                appliedRate = appliedRate,
                amount = finalAmount,
                status = TimeEntryStatus.NOT_PAID
            )
            
            app.container.timeEntryRepository.insertTimeEntry(entry)
            com.example.utils.AutoBackupManager.triggerBackup(app)
            
            withContext(Dispatchers.Main) {
                onSuccess()
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                onError(e.message ?: "Непредвиденная ошибка")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: @Composable () -> Unit,
    content: @Composable () -> Unit
) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier
                .width(IntrinsicSize.Min)
                .height(IntrinsicSize.Min)
                .background(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Выбор времени",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    textAlign = TextAlign.Start
                )
                content()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    dismissButton()
                    Spacer(modifier = Modifier.width(8.dp))
                    confirmButton()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaveSessionDialog(
    elapsedSeconds: Long,
    pauseSeconds: Long = 0L,
    initialClientId: Long?,
    initialComment: String = "",
    activeClients: List<Client>,
    globalHourlyRate: Double,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (clientId: Long, comment: String, hourlyRate: Double, finalDurationSeconds: Long) -> Unit
) {
    var selectedClientId by remember(elapsedSeconds) { 
        val lastId = TimerStateManager.getLastSelectedClientId()
        val defaultId = if (lastId != null && activeClients.any { it.id == lastId }) lastId else activeClients.firstOrNull()?.id ?: -1L
        mutableStateOf(initialClientId ?: defaultId) 
    }

    LaunchedEffect(activeClients) {
        if (selectedClientId == -1L && activeClients.isNotEmpty()) {
            val lastId = TimerStateManager.getLastSelectedClientId()
            val defaultId = if (lastId != null && activeClients.any { it.id == lastId }) lastId else activeClients.first().id
            selectedClientId = initialClientId ?: defaultId
        }
    }

    var comment by remember(elapsedSeconds) { mutableStateOf(initialComment) }
    
    // Convert elapsed seconds (actual work duration) to hours & minutes
    val initialHours = elapsedSeconds / 3600
    var initialMinutes = (elapsedSeconds % 3600) / 60
    if (elapsedSeconds > 0 && initialHours == 0L && initialMinutes == 0L) {
        initialMinutes = 1
    }
    
    val initialBreakMinutes = maxOf(0L, pauseSeconds / 60)
    
    var hoursStr by remember(elapsedSeconds) { mutableStateOf(initialHours.toString()) }
    var minutesStr by remember(elapsedSeconds) { mutableStateOf(initialMinutes.toString()) }
    var breakMinutesStr by remember(elapsedSeconds) { mutableStateOf(initialBreakMinutes.toString()) }
    
    // Hourly rate state, initialized to the default rate of selected client or global rate
    var hourlyRateStr by remember(selectedClientId) {
        val selectedClient = activeClients.find { it.id == selectedClientId }
        val initialRate = selectedClient?.defaultHourlyRate?.takeIf { it > 0.0 } ?: globalHourlyRate
        mutableStateOf(initialRate.toString())
    }
    
    // Update rate when client changes
    LaunchedEffect(selectedClientId, activeClients) {
        if (selectedClientId != -1L) {
            val client = activeClients.find { it.id == selectedClientId }
            hourlyRateStr = (client?.defaultHourlyRate?.takeIf { it > 0.0 } ?: globalHourlyRate).toString()
        }
    }
    
    var dropdownExpanded by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    // Parse values for calculations
    val hVal = hoursStr.toLongOrNull() ?: 0L
    val mVal = minutesStr.toLongOrNull() ?: 0L
    val bVal = breakMinutesStr.toLongOrNull() ?: 0L
    val rateVal = hourlyRateStr.toDoubleOrNull() ?: 0.0

    val calculatedDurationSeconds = maxOf(0L, (hVal * 3600) + (mVal * 60))
    val calculatedEarnings = (calculatedDurationSeconds.toDouble() / 3600.0) * rateVal

    if (showTimePicker) {
        val timePickerState = rememberTimePickerState(
            initialHour = hVal.toInt().coerceIn(0, 23),
            initialMinute = mVal.toInt().coerceIn(0, 59),
            is24Hour = true
        )
        
        TimePickerDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        hoursStr = timePickerState.hour.toString()
                        minutesStr = timePickerState.minute.toString()
                        showTimePicker = false
                    }
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) {
                    Text("Отмена")
                }
            }
        ) {
            MaterialTheme(
                typography = MaterialTheme.typography.copy(
                    bodyLarge = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp
                    ),
                    labelMedium = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp
                    )
                )
            ) {
                TimePicker(
                    state = timePickerState,
                    colors = customTimePickerColors()
                )
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("Сохранение сессии", fontWeight = FontWeight.Bold) },
        text = {
            Box(modifier = Modifier.fillMaxWidth()) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                ) {
                // 1. Display Earnings Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "ЗАРАБОТАНО ЗА СЕССИЮ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = formatCurrency(calculatedEarnings, currency),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                if (rateVal <= 0.0 || calculatedEarnings <= 0.0) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Предупреждение",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Предупреждение: Сумма работы 0. Укажите часовой тариф выше 0.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // 2. Rate Input
                OutlinedTextField(
                    value = hourlyRateStr,
                    onValueChange = { hourlyRateStr = it },
                    label = { Text("Часовой тариф ($currency/ч)") },
                    placeholder = { Text("Пример: 100") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                // 3. Work Duration and Break inputs
                // Break Duration (First!)
                OutlinedTextField(
                    value = breakMinutesStr,
                    onValueChange = { breakMinutesStr = it },
                    label = { Text("Время перерывов (минуты)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                // Work Duration Button (Second!)
                val formattedTime = String.format(Locale.US, "%02d:%02d", hVal, mVal)
                OutlinedButton(
                    onClick = { showTimePicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = "Select work time",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Время работы: $formattedTime",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 4. Comment input
                val keyboardController = LocalSoftwareKeyboardController.current
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Комментарий к сессии") },
                    placeholder = { Text("Например: Разработка макета") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        imeAction = ImeAction.Done,
                        keyboardType = KeyboardType.Text
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            keyboardController?.hide()
                        }
                    )
                )

                // 5. Client Selector at the bottom
                if (activeClients.isNotEmpty()) {
                    val currentClient = activeClients.find { it.id == selectedClientId }
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Заказчик",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        
                        Box(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = currentClient?.name ?: "Выберите заказчика",
                                onValueChange = {},
                                readOnly = true,
                                enabled = false,
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(safeParseColor(currentClient?.colorHex ?: "#EAD5A0"))
                                    )
                                },
                                trailingIcon = {
                                    val arrowRotation by animateFloatAsState(
                                        targetValue = if (dropdownExpanded) 180f else 0f,
                                        label = "ArrowRotation"
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown Arrow",
                                        modifier = Modifier.rotate(arrowRotation),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledContainerColor = Color.Transparent
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { dropdownExpanded = true },
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                } else {
                    Text(
                        text = "Нет доступных заказчиков. Сначала добавьте заказчика в соответствующей вкладке.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action buttons with equal width
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Сбросить")
                    }

                    Button(
                        onClick = {
                            val h = hoursStr.toLongOrNull() ?: 0L
                            val m = minutesStr.toLongOrNull() ?: 0L
                            val finalDurationSeconds = maxOf(0L, (h * 3600) + (m * 60))
                            val selectedClient = activeClients.find { it.id == selectedClientId }
                            val rate = hourlyRateStr.toDoubleOrNull()?.takeIf { it > 0.0 }
                                ?: (selectedClient?.defaultHourlyRate?.takeIf { it > 0.0 } ?: globalHourlyRate)
                            
                            onSave(selectedClientId, comment, rate, finalDurationSeconds)
                        },
                        enabled = selectedClientId != -1L && (hoursStr.isNotBlank() || minutesStr.isNotBlank()),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Сохранить", fontWeight = FontWeight.Bold)
                    }
                }
            }

            InlineClientSelectorSheet(
                expanded = dropdownExpanded,
                onDismiss = { dropdownExpanded = false },
                clients = activeClients,
                selectedClientId = selectedClientId,
                onClientSelected = { clientId ->
                    selectedClientId = clientId
                    TimerStateManager.setLastSelectedClientId(clientId)
                    dropdownExpanded = false
                }
            )
        }
    },
        confirmButton = {},
        dismissButton = null
    )
}

fun saveTrackedSessionEntry(
    clientId: Long,
    comment: String,
    rate: Double,
    durationSeconds: Long,
    scope: CoroutineScope,
    app: TimeSheetApp,
    settings: AppSettings,
    onSuccess: () -> Unit
) {
    scope.launch(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val startTime = now - (durationSeconds * 1000)
        
        // Time rounding (if configured)
        val roundingMinutes = settings.timeRoundingMinutes
        val finalDuration = if (roundingMinutes > 0) {
            val roundingSeconds = roundingMinutes * 60L
            if (durationSeconds % roundingSeconds == 0L) {
                durationSeconds
            } else {
                ((durationSeconds / roundingSeconds) + 1L) * roundingSeconds
            }
        } else {
            durationSeconds
        }
        
        // Calculate amount and round
        val effectiveRate = if (rate > 0.0) rate else settings.globalHourlyRate
        val rawAmount = (finalDuration.toDouble() / 3600.0) * effectiveRate
        val finalAmount = settings.roundAmount(rawAmount)
        
        val entry = TimeEntry(
            clientId = clientId,
            startTime = startTime,
            endTime = now,
            durationSeconds = finalDuration,
            rawDurationSeconds = durationSeconds,
            comment = comment.ifBlank { null },
            appliedRate = effectiveRate,
            amount = finalAmount,
            status = TimeEntryStatus.NOT_PAID
        )
        
        app.container.timeEntryRepository.insertTimeEntry(entry)
        com.example.utils.AutoBackupManager.triggerBackup(app)
        
        withContext(Dispatchers.Main) {
            onSuccess()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposeDatePickerDialog(
    initialTimeMs: Long,
    onDismissRequest: () -> Unit,
    onDateSelected: (Long) -> Unit
) {
    val datePickerState = rememberDatePickerState(
        initialSelectedDateMillis = initialTimeMs
    )
    val colors = MaterialTheme.colorScheme
    
    DatePickerDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            TextButton(
                onClick = {
                    datePickerState.selectedDateMillis?.let { dateUtc ->
                        val utcCal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
                            timeInMillis = dateUtc
                        }
                        val localCal = java.util.Calendar.getInstance().apply {
                            set(java.util.Calendar.YEAR, utcCal.get(java.util.Calendar.YEAR))
                            set(java.util.Calendar.MONTH, utcCal.get(java.util.Calendar.MONTH))
                            set(java.util.Calendar.DAY_OF_MONTH, utcCal.get(java.util.Calendar.DAY_OF_MONTH))
                            set(java.util.Calendar.HOUR_OF_DAY, 0)
                            set(java.util.Calendar.MINUTE, 0)
                            set(java.util.Calendar.SECOND, 0)
                            set(java.util.Calendar.MILLISECOND, 0)
                        }
                        onDateSelected(localCal.timeInMillis)
                    }
                    onDismissRequest()
                }
            ) {
                Text("OK", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Отмена")
            }
        },
        colors = DatePickerDefaults.colors(
            containerColor = colors.surface
        )
    ) {
        DatePicker(
            state = datePickerState,
            colors = DatePickerDefaults.colors(
                containerColor = colors.surface,
                titleContentColor = colors.onSurface,
                headlineContentColor = colors.onSurface,
                weekdayContentColor = colors.onSurface.copy(alpha = 0.6f),
                subheadContentColor = colors.onSurface.copy(alpha = 0.6f),
                navigationContentColor = colors.onSurface,
                yearContentColor = colors.onSurface.copy(alpha = 0.8f),
                selectedYearContentColor = colors.onPrimary,
                selectedYearContainerColor = colors.primary,
                dayContentColor = colors.onSurface,
                selectedDayContentColor = colors.onPrimary,
                selectedDayContainerColor = colors.primary,
                todayContentColor = colors.secondary,
                todayDateBorderColor = colors.secondary,
                dividerColor = colors.outline
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun customTimePickerColors(): TimePickerColors {
    val colors = MaterialTheme.colorScheme
    return TimePickerDefaults.colors(
        clockDialColor = colors.background,
        clockDialSelectedContentColor = colors.onPrimary,
        clockDialUnselectedContentColor = colors.onSurface,
        selectorColor = colors.primary,
        containerColor = colors.surface,
        periodSelectorBorderColor = colors.outline,
        periodSelectorSelectedContainerColor = colors.primary,
        periodSelectorUnselectedContainerColor = colors.surface,
        periodSelectorSelectedContentColor = colors.onPrimary,
        periodSelectorUnselectedContentColor = colors.onSurface,
        timeSelectorSelectedContainerColor = colors.primary,
        timeSelectorUnselectedContainerColor = colors.background,
        timeSelectorSelectedContentColor = colors.onPrimary,
        timeSelectorUnselectedContentColor = colors.onSurface
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InlineClientSelectorSheet(
    expanded: Boolean,
    onDismiss: () -> Unit,
    clients: List<Client>,
    selectedClientId: Long,
    onClientSelected: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    if (expanded) {
        ModalBottomSheet(
            onDismissRequest = onDismiss,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Выберите заказчика",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    clients.forEach { client ->
                        val isSelected = selectedClientId == client.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                    else Color.Transparent
                                )
                                .clickable {
                                    onClientSelected(client.id)
                                }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(safeParseColor(client.colorHex))
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = client.name,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
