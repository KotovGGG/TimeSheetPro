package com.example.ui.screens.clients

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.example.ui.screens.timer.TimerStateManager
import com.example.ui.screens.timer.TimerStatus
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entity.Client
import com.example.data.local.entity.RateHistoryEntry
import com.example.ui.AppViewModelProvider
import com.example.ui.screens.timer.formatCurrency
import com.example.ui.screens.timer.safeParseColor
import com.example.ui.theme.LedgerStyles
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ClientEditorState(
    val client: Client? = null, // null means adding a new client
    val name: String = "",
    val rate: String = "",
    val colorHex: String = "#D0BCFF"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientsScreen(
    modifier: Modifier = Modifier,
    viewModel: ClientsViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val clients by viewModel.clientsState.collectAsState()
    val settings by viewModel.settingsState.collectAsState()
    val unpaidBalances by viewModel.unpaidBalancesState.collectAsState()

    var editorState by remember { mutableStateOf<ClientEditorState?>(null) }
    var showDeleteConfirmDialogForClient by remember { mutableStateOf<Client?>(null) }

    val activeClients = remember(clients) { clients }

    val colorPresets = listOf(
        // Row 1: Reds, Corals, Oranges, Ambers, Golds
        "#E63946", // Crimson Red
        "#FF5A5F", // Soft Coral
        "#E76F51", // Terracotta Orange
        "#FB5607", // Intense Orange
        "#FF8533", // Bright Amber-Orange
        "#F4A261", // Sandy Amber
        "#DDA15E", // Warm Bronze
        "#FFBE0B", // Bright Gold
        
        // Row 2: Yellows, Warm Vanilla, Mint Greens, Emerald
        "#FFD166", // Soft Yellow
        "#E9D8A6", // Warm Vanilla
        "#76C893", // Mint Green
        "#52B788", // Forest Mint
        "#2D6A4F", // Deep Emerald
        "#00C49F", // Green Teal
        "#2EC4B6", // Emerald Teal
        "#A8DADC", // Soft Mint Cyan
        
        // Row 3: Cyans, Teal-Blues, Deep Blues, Royal Violets, Purples
        "#4CC9F0", // Sky Cyan
        "#48CAE4", // Bright Cyan
        "#00B4D8", // Bright Teal-Blue
        "#1A759F", // Ocean Blue
        "#0077B6", // Deep Azure
        "#3A86FF", // Electric Blue
        "#8338EC", // Royal Violet
        "#9B5DE5", // Amethyst Purple
        
        // Row 4: Orchids, Lavenders, Muted Slate, Dusty Roses, Pinks, Magentas
        "#C77DFF", // Pastel Orchid
        "#D0BCFF", // Premium Violet
        "#6D597A", // Muted Slate Violet
        "#B5838D", // Dusty Rose
        "#E8AEB2", // Soft Dusty Rose
        "#FF70A6", // Pastel Pink
        "#F15BB5", // Magenta
        "#FF2A6D"  // Neon Pink
    )

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editorState = ClientEditorState() },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .size(64.dp)
                    .testTag("add_client_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Добавить заказчика",
                    modifier = Modifier.size(32.dp)
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .testTag("clients_lazy_column"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // --- Header ---
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Заказчики",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        ),
                        modifier = Modifier.testTag("screen_title")
                    )
                }
            }


            // --- Active Clients list ---
            if (activeClients.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PeopleOutline,
                                contentDescription = "Empty",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "Нет добавленных заказчиков",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(activeClients, key = { it.id }) { client ->
                    val unpaidAmount = unpaidBalances[client.id] ?: 0.0
                    ClientCardItem(
                        client = client,
                        globalHourlyRate = settings.globalHourlyRate,
                        currency = settings.currency,
                        unpaidAmount = unpaidAmount,
                        onClick = {
                            editorState = ClientEditorState(
                                client = client,
                                name = client.name,
                                rate = client.defaultHourlyRate?.toString() ?: "",
                                colorHex = client.colorHex
                            )
                        }
                    )
                }
            }


        }
    }

    // --- Elegant Add/Edit Bottom Sheet ---
    editorState?.let { state ->
        val isEditMode = state.client != null
        val historyFlow = remember(state.client) {
            if (isEditMode) viewModel.getRateHistoryForClient(state.client!!.id) else null
        }
        val rateHistory by (historyFlow?.collectAsState(initial = emptyList()) ?: remember { mutableStateOf(emptyList()) })

        var nameInput by remember { mutableStateOf(state.name) }
        var rateInput by remember { mutableStateOf(state.rate) }
        var colorHexInput by remember { mutableStateOf(state.colorHex) }
        var isHistoryExpanded by remember { mutableStateOf(false) }

        ModalBottomSheet(
            onDismissRequest = { editorState = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            dragHandle = { BottomSheetDefaults.DragHandle() }
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp)
                    .testTag("client_editor_dialog_content")
            ) {
                // Header with Title
                Text(
                    text = if (isEditMode) "Редактировать заказчика" else "Добавить заказчика",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                // Name Field
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Имя / Название") },
                    placeholder = { Text("Напр., Рога и Копыта") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_client_name_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                // Personal Rate Field
                OutlinedTextField(
                    value = rateInput,
                    onValueChange = { rateInput = it },
                    label = { Text("Персональная ставка (опционально)") },
                    placeholder = { Text("Напр., 75.00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_client_rate_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    supportingText = {
                        Text("Оставьте пустым, чтобы использовать глобальную ставку")
                    }
                )

                // Color Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Цветовая гамма",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    colorPresets.chunked(8).forEachIndexed { rowIndex, rowColors ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(if (rowIndex == 0) Modifier.testTag("color_picker_row") else Modifier)
                        ) {
                            rowColors.forEach { hex ->
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(safeParseColor(hex))
                                        .border(
                                            width = if (colorHexInput == hex) 3.dp else 0.dp,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            shape = CircleShape
                                        )
                                        .clickable { colorHexInput = hex }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (isEditMode) {
                    val client = state.client!!
                    val context = LocalContext.current
                    val timerState by TimerStateManager.timerState.collectAsStateWithLifecycle()
                    val isTimerActiveForClient = timerState.status != TimerStatus.IDLE && timerState.clientId == client.id

                    OutlinedButton(
                        onClick = {
                            if (isTimerActiveForClient) {
                                Toast.makeText(context, "Нельзя удалить заказчика с активным таймером!", Toast.LENGTH_SHORT).show()
                            } else {
                                showDeleteConfirmDialogForClient = client
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("dialog_delete_button")
                    ) {
                        Text("Удалить заказчика", fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { editorState = null },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Отмена")
                    }

                    Button(
                        onClick = {
                            if (nameInput.isNotBlank()) {
                                val parsedRate = rateInput.toDoubleOrNull()?.takeIf { it > 0.0 }
                                val clientToSave = state.client?.copy(
                                    name = nameInput,
                                    colorHex = colorHexInput,
                                    defaultHourlyRate = parsedRate
                                ) ?: Client(
                                    name = nameInput,
                                    colorHex = colorHexInput,
                                    defaultHourlyRate = parsedRate,
                                    isArchived = false
                                )
                                
                                viewModel.saveClient(clientToSave, state.client?.defaultHourlyRate)
                                editorState = null
                            }
                        },
                        enabled = nameInput.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("dialog_confirm_button")
                    ) {
                        Text("Сохранить", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // --- Delete Client Confirm Dialog ---
    showDeleteConfirmDialogForClient?.let { client ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialogForClient = null },
            title = { Text("Удалить заказчика?") },
            text = {
                Text("Вы действительно хотите удалить заказчика \"${client.name}\"? Все связанные с ним данные будут сохранены, но самого заказчика нельзя будет вернуть. Это действие нельзя отменить.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteClient(client)
                        showDeleteConfirmDialogForClient = null
                        editorState = null // Close editor bottom sheet
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirmDialogForClient = null },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    Text("Отмена")
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(24.dp)
        )
    }
}

@Composable
fun ClientCardItem(
    client: Client,
    globalHourlyRate: Double,
    currency: String,
    unpaidAmount: Double = 0.0,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("client_card_${client.id}")
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .padding(vertical = 14.dp)
                .padding(start = 14.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Accent left border
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(safeParseColor(client.colorHex))
            )

            Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = client.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    
                    Text(
                        text = if (client.defaultHourlyRate != null && client.defaultHourlyRate > 0.0) {
                            formatCurrency(client.defaultHourlyRate, currency) + " / ч"
                        } else {
                            formatCurrency(globalHourlyRate, currency) + " / ч"
                        },
                        style = LedgerStyles.MonospaceNumberSmall.copy(fontSize = 13.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                if (unpaidAmount > 0.0) {
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(100.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(100.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                            .testTag("unpaid_balance_${client.id}")
                    ) {
                        Text(
                            text = formatCurrency(unpaidAmount, currency),
                            style = LedgerStyles.MonospaceNumberSmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Редактировать",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        }
    }
