package com.example.ui.screens.settings

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.entity.AmountRoundingMode
import com.example.data.local.entity.FirstDayOfWeek
import com.example.data.local.entity.ThemeMode
import com.example.ui.AppViewModelProvider
import com.example.ui.theme.LedgerStyles
import java.io.File
import java.text.SimpleDateFormat
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val context = LocalContext.current
    val settings by viewModel.settingsState.collectAsState()

    var globalRateString by remember { mutableStateOf("") }
    var roundingExpanded by remember { mutableStateOf(false) }
    var currencyMenuExpanded by remember { mutableStateOf(false) }
    var amountRoundingExpanded by remember { mutableStateOf(false) }

    // Sync input string with DB state
    LaunchedEffect(settings.globalHourlyRate) {
        if (settings.globalHourlyRate > 0.0) {
            globalRateString = settings.globalHourlyRate.toString()
        }
    }

    val roundingIntervals = listOf(
        0 to "Без округления",
        5 to "5 минут",
        10 to "10 минут",
        15 to "15 минут",
        30 to "30 минут"
    )

    val coroutineScope = rememberCoroutineScope()

    // --- Backup & Restore States ---
    var backupFileBytes by remember { mutableStateOf<ByteArray?>(null) }
    var backupFileName by remember { mutableStateOf("") }
    var showBackupSuccessCard by remember { mutableStateOf(false) }
    var showRestoreConfirmationDialog by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }

    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { uri ->
            if (uri != null && backupFileBytes != null) {
                try {
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(backupFileBytes)
                    }
                    Toast(context, "Резервная копия успешно сохранена!")
                } catch (e: Exception) {
                    Toast(context, "Ошибка сохранения: ${e.message}")
                }
            }
        }
    )

    val openBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                try {
                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        val jsonText = inputStream.bufferedReader().use { it.readText() }
                        pendingRestoreJson = jsonText
                        showRestoreConfirmationDialog = true
                    }
                } catch (e: Exception) {
                    Toast(context, "Ошибка чтения файла: ${e.message}")
                }
            }
        }
    )

    if (showRestoreConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreConfirmationDialog = false },
            title = {
                Text(
                    text = "Восстановление данных",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "ВНИМАНИЕ!\n\nВосстановление из резервной копии полностью заменит все текущие данные (заказчиков, историю ставок, записи времени и настройки).\n\nТекущие данные будут утеряны навсегда!\n\nЭто действие абсолютно необратимо. Вы действительно хотите продолжить?"
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showRestoreConfirmationDialog = false },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ОТМЕНА")
                        }
                        Button(
                            onClick = {
                                showRestoreConfirmationDialog = false
                                val json = pendingRestoreJson
                                if (json != null) {
                                    coroutineScope.launch {
                                        val result = viewModel.restoreBackupJson(json)
                                        if (result.isSuccess) {
                                            com.example.utils.AutoBackupManager.triggerBackup(context)
                                            Toast(context, "Данные успешно восстановлены!")
                                        } else {
                                            val err = result.exceptionOrNull()?.message ?: "Неизвестная ошибка"
                                            Toast(context, "Ошибка импорта: $err")
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ВОССТАНОВИТЬ")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = null,
            shape = RoundedCornerShape(16.dp),
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Настройки",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            )
        }

                // --- SECTION 1: Billing and Ledger Configuration ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    text = "НАСТРОЙКА ОПЛАТЫ И ВАЛЮТЫ",
                    style = LedgerStyles.UppercaseSectionHeader,
                    color = MaterialTheme.colorScheme.primary
                )

                // Global Hourly Rate Input
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Ставка по умолчанию",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = globalRateString,
                        onValueChange = { newValue ->
                            globalRateString = newValue
                            newValue.toDoubleOrNull()?.let {
                                viewModel.updateGlobalRate(it)
                            }
                        },
                        placeholder = { Text("Напр., 50.00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_global_rate_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background
                        ),
                        singleLine = true,
                        leadingIcon = {
                            val symbol = when (settings.currency) {
                                "USD" -> "$"
                                "EUR" -> "€"
                                "RUB" -> "₽"
                                "GBP" -> "£"
                                "KZT" -> "₸"
                                "JPY" -> "¥"
                                "BYN" -> "Br"
                                "CHF" -> "₣"
                                else -> settings.currency
                            }
                            Box(
                                modifier = Modifier
                                    .padding(start = 12.dp, end = 4.dp)
                                    .size(28.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = symbol,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    )
                }

                // Currency Input
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Базовая валюта",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val currencyArrowRotation by animateFloatAsState(
                        targetValue = if (currencyMenuExpanded) 180f else 0f,
                        label = "ArrowRotation"
                    )
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val menuWidth = maxWidth
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.background)
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { currencyMenuExpanded = true }
                                .padding(horizontal = 16.dp)
                                .testTag("settings_currency_input"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (settings.currency.isEmpty()) "USD" else settings.currency,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Quick selection list",
                                    modifier = Modifier.rotate(currencyArrowRotation),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (currencyMenuExpanded) {
                            ModalBottomSheet(
                                onDismissRequest = { currencyMenuExpanded = false },
                                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                dragHandle = { BottomSheetDefaults.DragHandle() }
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp)
                                        .padding(bottom = 32.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text(
                                        text = "Выберите валюту",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("USD", "EUR", "RUB", "GBP", "CHF", "JPY", "KZT", "BYN").forEach { cur ->
                                            val isSelected = (if (settings.currency.isEmpty()) "USD" else settings.currency) == cur
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                        else Color.Transparent
                                                    )
                                                    .clickable {
                                                        viewModel.updateCurrency(cur)
                                                        currencyMenuExpanded = false
                                                    }
                                                    .padding(16.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = cur,
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

                // --- SECTION 2: Precision & Calendar Parameters ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    text = "ОКРУГЛЕНИЕ И ИНТЕРВАЛЫ",
                    style = LedgerStyles.UppercaseSectionHeader,
                    color = MaterialTheme.colorScheme.primary
                )

                // Time Rounding Dropdown
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Округление рабочего времени",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val roundingArrowRotation by animateFloatAsState(
                        targetValue = if (roundingExpanded) 180f else 0f,
                        label = "ArrowRotation"
                    )
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val menuWidth = maxWidth
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.background)
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { roundingExpanded = true }
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val activeRoundingLabel = roundingIntervals.find { it.first == settings.timeRoundingMinutes }?.second ?: "Без округления"
                                Text(
                                    text = activeRoundingLabel,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Dropdown Arrow",
                                    modifier = Modifier.rotate(roundingArrowRotation),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (roundingExpanded) {
                            ModalBottomSheet(
                                onDismissRequest = { roundingExpanded = false },
                                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                dragHandle = { BottomSheetDefaults.DragHandle() }
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp)
                                        .padding(bottom = 32.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text(
                                        text = "Округление рабочего времени",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        roundingIntervals.forEach { (minutes, label) ->
                                            val isSelected = settings.timeRoundingMinutes == minutes
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                        else Color.Transparent
                                                    )
                                                    .clickable {
                                                        viewModel.updateTimeRounding(minutes)
                                                        roundingExpanded = false
                                                    }
                                                    .padding(16.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        text = "Временные записи будут округляться в финансовых подсчетах.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                // Amount Rounding Mode Dropdown
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Округление суммы",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val amountArrowRotation by animateFloatAsState(
                        targetValue = if (amountRoundingExpanded) 180f else 0f,
                        label = "ArrowRotation"
                    )
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val menuWidth = maxWidth
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.background)
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { amountRoundingExpanded = true }
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val modeLabel = when (settings.amountRoundingMode) {
                                    AmountRoundingMode.NONE -> "Без копеек (точно)"
                                    AmountRoundingMode.ROUND_UP -> "В пользу фрилансера (вверх)"
                                    AmountRoundingMode.ROUND_DOWN -> "В пользу клиента (вниз)"
                                    AmountRoundingMode.ROUND_NEAREST -> "Математическое округление"
                                }
                                Text(
                                    text = modeLabel,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Dropdown Arrow",
                                    modifier = Modifier.rotate(amountArrowRotation),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (amountRoundingExpanded) {
                            ModalBottomSheet(
                                onDismissRequest = { amountRoundingExpanded = false },
                                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                dragHandle = { BottomSheetDefaults.DragHandle() }
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 24.dp)
                                        .padding(bottom = 32.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text(
                                        text = "Округление суммы",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        val options = listOf(
                                            AmountRoundingMode.NONE to "Без копеек (точно)",
                                            AmountRoundingMode.ROUND_UP to "В пользу фрилансера (вверх)",
                                            AmountRoundingMode.ROUND_DOWN to "В пользу клиента (вниз)",
                                            AmountRoundingMode.ROUND_NEAREST to "Математическое округление"
                                        )
                                        options.forEach { (mode, label) ->
                                            val isSelected = settings.amountRoundingMode == mode
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(
                                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                        else Color.Transparent
                                                    )
                                                    .clickable {
                                                        viewModel.updateAmountRoundingMode(mode)
                                                        amountRoundingExpanded = false
                                                    }
                                                    .padding(16.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = label,
                                                    style = MaterialTheme.typography.bodyLarge,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

                // --- SECTION 3: Theme & Appearance ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    text = "ТЕМА И ОФОРМЛЕНИЕ",
                    style = LedgerStyles.UppercaseSectionHeader,
                    color = MaterialTheme.colorScheme.primary
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Тема оформления",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            ThemeMode.LIGHT to "СВЕТЛАЯ",
                            ThemeMode.DARK to "ТЁМНАЯ",
                            ThemeMode.SYSTEM to "СИСТЕМНАЯ"
                        ).forEach { (mode, label) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (settings.themeMode == mode)
                                            MaterialTheme.colorScheme.primary
                                        else
                                            Color.Transparent
                                    )
                                    .clickable { viewModel.updateThemeMode(mode) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (settings.themeMode == mode)
                                        MaterialTheme.colorScheme.onPrimary
                                    else
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

                // --- SECTION 4: Backup & Restore ---
        Card(
            modifier = Modifier.fillMaxWidth().testTag("backup_restore_card"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    text = "РЕЗЕРВНАЯ КОПИЯ",
                    style = LedgerStyles.UppercaseSectionHeader,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "Экспортируйте или восстановите данные (заказчиков, записи и настройки) с помощью JSON-файла.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    if (maxWidth < 360.dp) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Create Backup Button
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        try {
                                            val json = viewModel.createBackupJson()
                                            backupFileBytes = json.toByteArray(Charsets.UTF_8)
                                            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault()).format(Date())
                                            backupFileName = "TimeSheetPro_Backup_$dateStr.json"
                                            showBackupSuccessCard = true
                                            Toast(context, "Резервная копия успешно создана!")
                                        } catch (e: Exception) {
                                            Toast(context, "Ошибка бэкапа: ${e.message}")
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.CloudDownload, contentDescription = "Create Backup")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("БЭКАП", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            // Restore Backup Button
                            OutlinedButton(
                                onClick = {
                                    openBackupLauncher.launch("*/*")
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.CloudUpload, contentDescription = "Restore Backup")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ВОССТАНОВИТЬ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Create Backup Button
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        try {
                                            val json = viewModel.createBackupJson()
                                            backupFileBytes = json.toByteArray(Charsets.UTF_8)
                                            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.getDefault()).format(Date())
                                            backupFileName = "TimeSheetPro_Backup_$dateStr.json"
                                            showBackupSuccessCard = true
                                            Toast(context, "Резервная копия успешно создана!")
                                        } catch (e: Exception) {
                                            Toast(context, "Ошибка бэкапа: ${e.message}")
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.CloudDownload, contentDescription = "Create Backup")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("БЭКАП", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            // Restore Backup Button
                            OutlinedButton(
                                onClick = {
                                    openBackupLauncher.launch("*/*")
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.CloudUpload, contentDescription = "Restore Backup")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ВОССТАНОВИТЬ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Success Backup Card (Save, Share)
                AnimatedVisibility(visible = showBackupSuccessCard) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.background)
                            .border(width = 2.dp, color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Success", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                        Text(
                            text = "Бэкап успешно создан!",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = backupFileName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // 1. Share button
                            Button(
                                onClick = {
                                    try {
                                        backupFileBytes?.let { bytes ->
                                            val cacheFile = File(context.cacheDir, backupFileName)
                                            cacheFile.writeBytes(bytes)
                                            val authority = "${context.packageName}.fileprovider"
                                            val uri = FileProvider.getUriForFile(context, authority, cacheFile)

                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/json"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Поделиться бэкапом"))
                                        }
                                    } catch (e: Exception) {
                                        Toast(context, "Ошибка при шаринге: ${e.message}")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Поделиться", fontSize = 12.sp)
                            }

                            // 2. Save As SAF
                            Button(
                                onClick = {
                                    createBackupLauncher.launch(backupFileName)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.Save, contentDescription = "Save As")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Сохранить...", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // --- FOOTER INFO ---
        val appVersionName = remember(context) {
            try {
                val packageInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    context.packageManager.getPackageInfo(context.packageName, android.content.pm.PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    context.packageManager.getPackageInfo(context.packageName, 0)
                }
                "v${packageInfo.versionName}"
            } catch (e: Exception) {
                "v1.6.0"
            }
        }

        Text(
            text = appVersionName,
            style = LedgerStyles.UppercaseSectionHeader,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        )
    }
    }

    if (currencyMenuExpanded || roundingExpanded || amountRoundingExpanded) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.15f))
                .pointerInput(Unit) {
                    detectTapGestures {
                        currencyMenuExpanded = false
                        roundingExpanded = false
                        amountRoundingExpanded = false
                    }
                }
        )
    }
}

// Simple Toast helper
private fun Toast(context: android.content.Context, message: String) {
    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
}
