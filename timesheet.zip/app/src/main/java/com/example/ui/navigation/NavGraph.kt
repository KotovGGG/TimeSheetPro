package com.example.ui.navigation

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.clients.ClientsScreen
import com.example.ui.screens.records.RecordsScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.timer.TimerScreen

@Composable
fun MainAppNavigation(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val screens = listOf(
        Screen.Timer,
        Screen.Records,
        Screen.Clients,
        Screen.Settings
    )

    Scaffold(
        bottomBar = {
            val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            NavigationBar(
                modifier = Modifier
                    .testTag("bottom_nav_bar")
                    .height(76.dp + bottomInset),
                containerColor = Color(0xFF181820),
                tonalElevation = 0.dp
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                screens.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != screen.route) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.background,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = if (MaterialTheme.colorScheme.background == com.example.ui.theme.LightBackground) {
                                Color(0xFF525065)
                            } else {
                                MaterialTheme.colorScheme.outline
                            },
                            unselectedTextColor = if (MaterialTheme.colorScheme.background == com.example.ui.theme.LightBackground) {
                                Color(0xFF525065)
                            } else {
                                MaterialTheme.colorScheme.outline
                            },
                            indicatorColor = MaterialTheme.colorScheme.primary
                        ),
                        icon = {
                            Icon(
                                imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                contentDescription = screen.label
                            )
                        },
                        label = { Text(screen.label) },
                        modifier = Modifier.testTag("nav_item_${screen.route}")
                    )
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Timer.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Timer.route) {
                TimerScreen()
            }
            composable(Screen.Records.route) {
                RecordsScreen()
            }
            composable(Screen.Clients.route) {
                ClientsScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}
