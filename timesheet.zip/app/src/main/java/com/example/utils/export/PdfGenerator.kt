package com.example.utils.export

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.data.local.entity.Client
import com.example.data.local.entity.TimeEntry
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {

    fun generatePdf(
        entries: List<TimeEntry>,
        clients: List<Client>,
        selectedClientNames: String,
        periodLabel: String,
        currencySymbol: String
    ): ByteArray {
        val pdfDocument = PdfDocument()
        val paint = Paint()
        val clientMap = clients.associateBy { it.id }

        // Standard A4 dimensions: 595 x 842 postscript points
        val pageWidth = 595
        val pageHeight = 842

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        // Colors based on Ledger design system
        val colorPrimary = Color.parseColor("#C5A059") // Brass Accent
        val colorInkText = Color.parseColor("#1C1C1C") // Ink Text
        val colorPaperBackground = Color.parseColor("#FCFAF2") // Warm Paper Background
        val colorDivider = Color.parseColor("#E0DCCF") // Ledger divider lines
        val colorSecondaryText = Color.parseColor("#7A7563") // Secondary Ink Text

        // Draw Paper Background
        fun drawBackground(canvas: Canvas) {
            paint.color = colorPaperBackground
            paint.style = Paint.Style.FILL
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), paint)
        }

        // Draw Headers & Layout structure
        fun drawHeader(canvas: Canvas, pageNum: Int) {
            // Top Brass accent banner
            paint.color = colorPrimary
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, paint)

            // App/Document Branding
            paint.color = colorPrimary
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            paint.textSize = 10f
            paint.letterSpacing = 0.2f
            canvas.drawText("TIMESHEETPRO • СЧЁТ И ИНВОЙС", 40f, 42f, paint)

            paint.color = colorInkText
            paint.textSize = 28f
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            canvas.drawText("ИНВОЙС / INVOICE", 40f, 80f, paint)

            // Divider Line
            paint.color = colorPrimary
            paint.strokeWidth = 2f
            canvas.drawLine(40f, 94f, (pageWidth - 40).toFloat(), 94f, paint)

            // Invoice Meta details
            paint.color = colorSecondaryText
            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            val currentDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            canvas.drawText("ДАТА ФОРМИРОВАНИЯ: $currentDate", 40f, 112f, paint)
            canvas.drawText("ЗАКАЗЧИК(И): $selectedClientNames", 40f, 126f, paint)
            canvas.drawText("ПЕРИОД: $periodLabel", 40f, 140f, paint)

            // Page Number
            canvas.drawText("СТРАНИЦА $pageNum", (pageWidth - 90).toFloat(), 42f, paint)
        }

        drawBackground(canvas)
        drawHeader(canvas, pageNumber)

        // Draw Table Header
        var currentY = 175f

        fun drawTableHeader(canvas: Canvas) {
            paint.color = colorDivider
            paint.style = Paint.Style.FILL
            canvas.drawRect(40f, currentY - 14f, (pageWidth - 40).toFloat(), currentY + 12f, paint)

            paint.color = colorInkText
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            canvas.drawText("ДАТА", 46f, currentY + 3f, paint)
            canvas.drawText("ЗАКАЗЧИК", 130f, currentY + 3f, paint)
            canvas.drawText("КОММЕНТАРИЙ", 240f, currentY + 3f, paint)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("ВРЕМЯ", (pageWidth - 140).toFloat(), currentY + 3f, paint)
            canvas.drawText("СУММА", (pageWidth - 46).toFloat(), currentY + 3f, paint)
            paint.textAlign = Paint.Align.LEFT
        }

        drawTableHeader(canvas)
        currentY += 28f

        // Draw Rows
        val rowHeight = 24f
        val maxContentY = pageHeight - 80f // leave room for footer/totals

        val fontMonospace = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val fontSansNormal = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)

        fun drawTextTruncated(canvas: Canvas, text: String, x: Float, y: Float, paint: Paint, maxWidth: Float) {
            val width = paint.measureText(text)
            if (width <= maxWidth) {
                canvas.drawText(text, x, y, paint)
            } else {
                var tempText = text
                while (tempText.isNotEmpty() && paint.measureText("$tempText...") > maxWidth) {
                    tempText = tempText.dropLast(1)
                }
                canvas.drawText("$tempText...", x, y, paint)
            }
        }

        var totalSum = 0.0

        entries.forEach { entry ->
            totalSum += entry.amount

            if (currentY > maxContentY) {
                // Finish page and start a new one
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas

                drawBackground(canvas)
                drawHeader(canvas, pageNumber)

                currentY = 175f
                drawTableHeader(canvas)
                currentY += 28f
            }

            // Zebra background striping
            paint.color = if (entries.indexOf(entry) % 2 == 0) Color.parseColor("#F4F1E6") else Color.TRANSPARENT
            if (paint.color != Color.TRANSPARENT) {
                paint.style = Paint.Style.FILL
                canvas.drawRect(40f, currentY - 14f, (pageWidth - 40).toFloat(), currentY + 10f, paint)
            }

            // Bottom row border
            paint.color = colorDivider
            paint.strokeWidth = 0.5f
            canvas.drawLine(40f, currentY + 10f, (pageWidth - 40).toFloat(), currentY + 10f, paint)

            // Format date
            val dateStr = SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault()).format(Date(entry.startTime))
            paint.color = colorInkText
            paint.textSize = 9f
            paint.typeface = fontSansNormal
            canvas.drawText(dateStr, 46f, currentY, paint)

            // Client name
            val clientName = clientMap[entry.clientId]?.name ?: "Заказчик #${entry.clientId}"
            drawTextTruncated(canvas, clientName, 130f, currentY, paint, 100f)

            // Comment
            val comment = entry.comment ?: "—"
            drawTextTruncated(canvas, comment, 240f, currentY, paint, 160f)

            // Duration
            paint.typeface = fontMonospace
            val hours = entry.durationSeconds / 3600
            val minutes = (entry.durationSeconds % 3600) / 60
            val durationStr = String.format(Locale.getDefault(), "%dч %02dм", hours, minutes)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText(durationStr, (pageWidth - 140).toFloat(), currentY, paint)

            // Amount
            val amountStr = String.format(Locale.getDefault(), "%.2f", entry.amount)
            canvas.drawText(amountStr, (pageWidth - 46).toFloat(), currentY, paint)
            paint.textAlign = Paint.Align.LEFT

            currentY += rowHeight
        }

        // Check if totals fit on the current page, otherwise start a final page
        if (currentY > maxContentY - 60f) {
            pdfDocument.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas

            drawBackground(canvas)
            drawHeader(canvas, pageNumber)
            currentY = 175f
        }

        // Draw Ledger Totals Block
        currentY += 15f
        paint.color = colorPrimary
        paint.style = Paint.Style.FILL
        canvas.drawRect(40f, currentY, (pageWidth - 40).toFloat(), currentY + 4f, paint)

        currentY += 30f
        paint.color = colorInkText
        paint.textSize = 12f
        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        canvas.drawText("ИТОГОВАЯ СУММА К ОПЛАТЕ:", 46f, currentY, paint)

        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 18f
        paint.typeface = fontMonospace
        val totalSumStr = String.format(Locale.getDefault(), "%,.2f %s", totalSum, currencySymbol)
        canvas.drawText(totalSumStr, (pageWidth - 46).toFloat(), currentY + 3f, paint)
        paint.textAlign = Paint.Align.LEFT

        // Invoice footer note
        currentY += 40f
        paint.color = colorSecondaryText
        paint.textSize = 8f
        paint.typeface = fontSansNormal
        canvas.drawText("Спасибо за сотрудничество! Данный документ сформирован в приложении TimeSheetPro.", 46f, currentY, paint)

        pdfDocument.finishPage(page)

        val bos = ByteArrayOutputStream()
        pdfDocument.writeTo(bos)
        pdfDocument.close()

        return bos.toByteArray()
    }
}
